import os
import subprocess
from typing import List, Optional, Dict, Tuple
from pathlib import Path
from logger import get_logger
from lsf_runner import LSFRunner, LocalRunner


class QCRunner:
    def __init__(self, script: str = "run_qc.py", config_split: str = None,
                 results_dir: str = "results", log_dir: str = "logs",
                 lsf_config: dict = None, local_runner: LocalRunner = None):
        self.script = script
        self.config_split = config_split
        self.results_dir = results_dir
        self.log_dir = log_dir
        self.logger = get_logger('QCRunner')

        if lsf_config:
            self.lsf_runner = LSFRunner(
                queue=lsf_config.get('queue', 'normal'),
                max_jobs=lsf_config.get('max_jobs', 50),
                timeout=lsf_config.get('timeout', 3600),
                retry=lsf_config.get('retry', 3),
                project_name=lsf_config.get('project_name', 'regression_qc')
            )
        else:
            self.lsf_runner = None

        self.local_runner = local_runner or LocalRunner()

    def run_qc(self, input_files: List[str], workspace: Path,
               config_file: str = None, use_lsf: bool = False) -> Dict[str, str]:
        if not input_files:
            self.logger.warning("No input files for QC")
            return {}

        self.logger.info(f"Running QC for {len(input_files)} files")

        config = config_file or self.config_split

        if use_lsf and self.lsf_runner:
            return self._run_lsf(input_files, workspace, config)
        else:
            return self._run_local(input_files, workspace, config)

    def _build_command(self, input_files: List[str], workspace: Path, config: str) -> str:
        input_str = " ".join(input_files)
        output_dir = workspace / "output"
        output_dir.mkdir(parents=True, exist_ok=True)

        cmd_parts = []
        if self.script.endswith('.py'):
            cmd_parts = ["python", self.script]
        elif self.script.endswith('.pl'):
            cmd_parts = ["perl", self.script]
        else:
            cmd_parts = [self.script]

        cmd_parts.extend([
            "--input", input_str,
            "--output", str(output_dir),
            "--config", config
        ])

        return " ".join(cmd_parts)

    def _run_local(self, input_files: List[str], workspace: Path,
                   config: str) -> Dict[str, str]:
        results = {}

        for file_group in self._group_files(input_files):
            cmd = self._build_command(file_group, workspace, config)
            return_code, stdout, stderr = self.local_runner.run_command(cmd, cwd=str(workspace))

            if return_code == 0:
                self.logger.info(f"QC completed successfully for {len(file_group)} files")
                for f in file_group:
                    results[f] = "PASS"
            else:
                self.logger.error(f"QC failed: {stderr}")
                for f in file_group:
                    results[f] = "FAIL"

        return results

    def _run_lsf(self, input_files: List[str], workspace: Path,
                 config: str) -> Dict[str, str]:
        job_ids = []

        for i, file_group in enumerate(self._group_files(input_files)):
            cmd = self._build_command(file_group, workspace, config)
            job_name = f"qc_{i}_{int(time.time())}"
            job_id = self.lsf_runner.submit_job(cmd, job_name=job_name,
                                               working_dir=str(workspace))
            job_ids.append(job_id)

        results_map = self.lsf_runner.wait_for_jobs(job_ids)

        results = {}
        for i, job_id in enumerate(job_ids):
            file_group = list(self._group_files(input_files))[i]
            if results_map.get(job_id, (False, None))[0]:
                for f in file_group:
                    results[f] = "PASS"
            else:
                for f in file_group:
                    results[f] = "FAIL"

        return results

    def _group_files(self, files: List[str], group_size: int = 10) -> List[List[str]]:
        return [files[i:i + group_size] for i in range(0, len(files), group_size)]

    def run_single_qc(self, input_file: str, output_dir: str,
                       config: str = None) -> Tuple[bool, str]:
        config = config or self.config_split

        cmd_parts = []
        if self.script.endswith('.py'):
            cmd_parts = ["python", self.script]
        elif self.script.endswith('.pl'):
            cmd_parts = ["perl", self.script]
        else:
            cmd_parts = [self.script]

        cmd_parts.extend([
            "--input", input_file,
            "--output", output_dir,
            "--config", config
        ])

        cmd = " ".join(cmd_parts)
        return_code, stdout, stderr = self.local_runner.run_command(cmd)

        if return_code == 0:
            self.logger.info(f"QC passed for {input_file}")
            return True, stdout
        else:
            self.logger.error(f"QC failed for {input_file}: {stderr}")
            return False, stderr


import time


class QCResult:
    def __init__(self, file_name: str, status: str, output: str = None,
                 error: str = None, duration: float = 0.0):
        self.file_name = file_name
        self.status = status
        self.output = output
        self.error = error
        self.duration = duration

    def to_dict(self) -> dict:
        return {
            "file": self.file_name,
            "status": self.status,
            "output": self.output,
            "error": self.error,
            "duration": self.duration
        }


def create_qc_runner(config: dict, lsf_config: dict = None) -> QCRunner:
    return QCRunner(
        script=config.get('script', 'run_qc.py'),
        config_split=config.get('config_split'),
        results_dir=config.get('results_dir', 'results'),
        log_dir=config.get('log_dir', 'logs'),
        lsf_config=lsf_config
    )