#!/usr/bin/env python3
"""
Test suite for Regression QC System
Compatible with Python 3.9+
"""

import os
import sys
import pytest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from logger import QCLogger, get_logger


class TestQCLogger:
    def test_logger_singleton(self):
        logger1 = QCLogger.get_instance()
        logger2 = QCLogger.get_instance()
        assert logger1 is logger2

    def test_logger_setup(self, tmp_path):
        config = {
            'logging': {
                'level': 'DEBUG',
                'console': True,
                'file': str(tmp_path / 'test.log'),
                'format': '%(levelname)s - %(message)s'
            }
        }
        logger = QCLogger(config)
        result = logger.setup()
        assert result is not None

    def test_logger_levels(self):
        config = {
            'logging': {
                'level': 'DEBUG',
                'console': False
            }
        }
        logger = QCLogger.get_instance(config)
        logger.setup()
        logger.debug("debug message")
        logger.info("info message")
        logger.warning("warning message")
        logger.error("error message")

    def test_get_logger_with_name(self):
        config = {
            'logging': {
                'level': 'INFO',
                'console': False
            }
        }
        logger = get_logger('test')
        assert logger.name == 'RegressionQC.test'


class TestConfigLoader:
    def test_config_singleton(self, tmp_path):
        from config_loader import ConfigLoader
        ConfigLoader._instance = None
        ConfigLoader._config = {}

        config_file = tmp_path / "test_config.yaml"
        config_file.write_text("""
workspace: /tmp/test
golden:
  path: /tmp/golden
""")

        loader1 = ConfigLoader.get_instance(str(config_file))
        loader2 = ConfigLoader.get_instance()
        assert loader1 is loader2

    def test_load_config_from_file(self, tmp_path):
        config_file = tmp_path / "test_config.yaml"
        config_file.write_text("""
workspace: /tmp/test
golden:
  path: /tmp/golden
  diff_mode: text
qc:
  script: test.py
""")

        from config_loader import ConfigLoader
        loader = ConfigLoader(str(config_file))
        config = loader.load()

        assert config['workspace'] == '/tmp/test'
        assert config['golden']['path'] == '/tmp/golden'
        assert config['qc']['script'] == 'test.py'

    def test_config_defaults(self, tmp_path):
        config_file = tmp_path / "test_config.yaml"
        config_file.write_text("""
workspace: /tmp/test
golden:
  path: /tmp/golden
""")

        from config_loader import ConfigLoader
        loader = ConfigLoader(str(config_file))
        config = loader.load()

        assert config['lsf']['queue'] == 'normal'
        assert config['logging']['level'] == 'INFO'

    def test_config_get_method(self, tmp_path):
        config_file = tmp_path / "test_config.yaml"
        config_file.write_text("""
workspace: /tmp/test
golden:
  path: /tmp/golden
  diff_mode: hash
""")

        from config_loader import ConfigLoader
        loader = ConfigLoader(str(config_file))
        loader.load()

        assert loader.get('workspace') == '/tmp/test'
        assert loader.get('golden.diff_mode') == 'hash'
        assert loader.get('nonexistent', 'default') == 'default'


class TestGitUtils:
    def test_is_repo_non_git(self, tmp_path):
        from git_utils import GitUtils
        git = GitUtils(str(tmp_path))
        result = git.is_repo()
        assert result == False

    def test_filter_files_by_pattern(self):
        from git_utils import GitUtils
        files = ['test.v', 'test.txt', 'module.sv', 'module.vhd']

        result = GitUtils().filter_files_by_pattern(
            files,
            include_patterns=['*.v', '*.sv']
        )
        assert 'test.v' in result
        assert 'module.sv' in result
        assert 'test.txt' not in result

    def test_filter_exclude_patterns(self):
        from git_utils import GitUtils
        files = ['test.v', 'test.log', 'test.tmp']

        result = GitUtils().filter_files_by_pattern(
            files,
            exclude_patterns=['*.log', '*.tmp']
        )
        assert 'test.v' in result
        assert 'test.log' not in result
        assert 'test.tmp' not in result


class TestWorkspaceManager:
    def test_create_workspace(self, tmp_path):
        from workspace import WorkspaceManager

        wm = WorkspaceManager(str(tmp_path))
        workspace = wm.create_workspace("test")

        assert workspace.exists()
        assert (workspace / "input").exists()
        assert (workspace / "output").exists()
        assert (workspace / "logs").exists()

    def test_copy_files(self, tmp_path):
        from workspace import WorkspaceManager

        input_dir = tmp_path / "input"
        input_dir.mkdir()
        (input_dir / "test.v").write_text("module test;")

        wm = WorkspaceManager(str(tmp_path))
        workspace = wm.create_workspace("test")

        copied = wm.copy_files(["test.v"], str(input_dir), preserve_structure=False)

        assert len(copied) == 1
        assert (workspace / "input" / "test.v").exists()

    def test_workspace_cleanup(self, tmp_path):
        from workspace import WorkspaceManager

        wm = WorkspaceManager(str(tmp_path))
        workspace = wm.create_workspace("test")

        wm.cleanup()
        assert not workspace.exists()

    def test_workspace_keep_files(self, tmp_path):
        from workspace import WorkspaceManager

        wm = WorkspaceManager(str(tmp_path), keep_files=True)
        workspace = wm.create_workspace("test")

        wm.cleanup()
        assert workspace.exists()


class TestDiffChecker:
    def test_diff_checker_init(self, tmp_path):
        from diff_checker import DiffChecker

        golden_dir = tmp_path / "golden"
        golden_dir.mkdir()

        checker = DiffChecker(str(golden_dir), diff_mode='text')
        assert checker.golden_path == golden_dir
        assert checker.diff_mode == 'text'

    def test_should_ignore_patterns(self, tmp_path):
        from diff_checker import DiffChecker

        checker = DiffChecker(
            str(tmp_path),
            ignore_patterns=['*.tmp', '*.log']
        )

        assert checker._should_ignore('test.tmp') == True
        assert checker._should_ignore('test.log') == True
        assert checker._should_ignore('test.v') == False

    def test_file_list(self, tmp_path):
        from diff_checker import DiffChecker

        golden = tmp_path / "golden"
        golden.mkdir()
        (golden / "file1.v").write_text("content1")
        (golden / "file2.v").write_text("content2")

        checker = DiffChecker(str(golden))
        files = checker._get_file_list(golden)

        assert len(files) == 2
        assert "file1.v" in files
        assert "file2.v" in files

    def test_identical_files_match(self, tmp_path):
        from diff_checker import DiffChecker

        golden = tmp_path / "golden"
        new = tmp_path / "new"
        golden.mkdir()
        new.mkdir()

        (golden / "test.v").write_text("module test;\nendmodule")
        (new / "test.v").write_text("module test;\nendmodule")

        checker = DiffChecker(str(golden), diff_mode='text')
        summary = checker.check(str(new))

        assert summary.total_files == 1
        assert summary.matched == 1
        assert summary.pass_ == True

    def test_different_files_detected(self, tmp_path):
        from diff_checker import DiffChecker

        golden = tmp_path / "golden"
        new = tmp_path / "new"
        golden.mkdir()
        new.mkdir()

        (golden / "test.v").write_text("module test;\nendmodule")
        (new / "test.v").write_text("module test_modified;\nendmodule")

        checker = DiffChecker(str(golden), diff_mode='text')
        summary = checker.check(str(new))

        assert summary.total_files == 1
        assert summary.diff == 1
        assert summary.pass_ == False

    def test_hash_mode(self, tmp_path):
        from diff_checker import DiffChecker

        golden = tmp_path / "golden"
        new = tmp_path / "new"
        golden.mkdir()
        new.mkdir()

        (golden / "test.v").write_text("module test;\nendmodule")
        (new / "test.v").write_text("module test;\nendmodule")

        checker = DiffChecker(str(golden), diff_mode='hash')
        summary = checker.check(str(new))

        assert summary.pass_ == True


class TestLSFRunner:
    def test_lsf_runner_init(self):
        from lsf_runner import LSFRunner

        runner = LSFRunner(
            queue='normal',
            max_jobs=10,
            timeout=600
        )

        assert runner.queue == 'normal'
        assert runner.max_jobs == 10
        assert runner.timeout == 600

    def test_local_runner_init(self):
        from lsf_runner import LocalRunner

        runner = LocalRunner(max_workers=4)
        assert runner.max_workers == 4


class TestFileGenerator:
    def test_file_generator_init(self):
        from file_generator import FileGenerator

        gen = FileGenerator(
            script='test.pl',
            parallel=True,
            max_workers=5
        )

        assert gen.script == 'test.pl'
        assert gen.parallel == True
        assert gen.max_workers == 5


class TestQCRunner:
    def test_qc_runner_init(self):
        from qc_runner import QCRunner

        runner = QCRunner(
            script='run_qc.py',
            results_dir='results'
        )

        assert runner.script == 'run_qc.py'
        assert runner.results_dir == 'results'


class TestIntegration:
    def test_full_workflow(self, tmp_path):
        golden_dir = tmp_path / "golden"
        new_dir = tmp_path / "new"
        golden_dir.mkdir()
        new_dir.mkdir()

        (golden_dir / "File_New_module.v").write_text("""========================================
QC Report
Module: test
Verification: PASS
========================================""")

        (new_dir / "File_New_module.v").write_text("""========================================
QC Report
Module: test
Verification: PASS
========================================""")

        from diff_checker import DiffChecker

        checker = DiffChecker(str(golden_dir))
        summary = checker.check(str(new_dir))

        assert summary.pass_ == True
        assert summary.matched == 1
        assert summary.diff == 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])