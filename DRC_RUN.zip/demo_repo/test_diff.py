#!/usr/bin/env python3
import sys
sys.path.insert(0, 'c:/HLGUO/project/DRC_RUN/regression_qc')

from diff_checker import DiffChecker

checker = DiffChecker(
    golden_path='c:/HLGUO/project/DRC_RUN/regression_qc/test_data/golden/output',
    diff_mode='text'
)

summary = checker.check(
    'c:/HLGUO/project/DRC_RUN/regression_qc/test_data/output',
    output_report='c:/HLGUO/project/DRC_RUN/regression_qc/test_data/diff_report.txt'
)

print('=' * 60)
print('DIFF CHECK RESULT')
print('=' * 60)
print(f'Total Files: {summary.total_files}')
print(f'Matched: {summary.matched}')
print(f'Diff: {summary.diff}')
print(f'Missing in New: {summary.missing_in_new}')
print(f'Missing in Golden: {summary.missing_in_golden}')
result_text = "PASS" if summary.pass_ else "FAIL"
print(f'Result: {result_text}')