import os
import subprocess
from pathlib import Path
from typing import List, Optional, Dict
from logger import get_logger


class GitUtils:
    def __init__(self, git_root: str = None):
        self.git_root = git_root or self._find_git_root()
        self.logger = get_logger('GitUtils')

    def _find_git_root(self) -> str:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--show-toplevel'],
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return os.getcwd()

    def _run_git(self, args: List[str], cwd: str = None) -> subprocess.CompletedProcess:
        cwd = cwd or self.git_root
        self.logger.debug(f"Running git {' '.join(args)}")
        return subprocess.run(
            ['git'] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=True
        )

    def is_repo(self) -> bool:
        try:
            self._run_git(['rev-parse', '--git-dir'])
            return True
        except subprocess.CalledProcessError:
            return False

    def get_staged_files(self) -> List[str]:
        try:
            result = self._run_git(['diff', '--cached', '--name-only'])
            files = [f.strip() for f in result.stdout.strip().split('\n') if f.strip()]
            self.logger.info(f"Staged files: {len(files)}")
            return files
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to get staged files: {e}")
            return []

    def get_modified_files(self, since: str = 'HEAD~1') -> List[str]:
        try:
            result = self._run_git(['diff', '--name-only', f'{since}..HEAD'])
            files = [f.strip() for f in result.stdout.strip().split('\n') if f.strip()]
            self.logger.info(f"Modified files since {since}: {len(files)}")
            return files
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to get modified files: {e}")
            return []

    def get_all_changed_files(self, since: str = 'HEAD~1') -> List[str]:
        staged = self.get_staged_files()
        modified = self.get_modified_files(since)

        all_files = list(set(staged + modified))
        self.logger.info(f"Total changed files: {len(all_files)}")
        return all_files

    def get_file_diff(self, file_path: str, staged: bool = True) -> str:
        try:
            args = ['diff'] + (['--cached'] if staged else []) + ['--', file_path]
            result = self._run_git(args)
            return result.stdout
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to get diff for {file_path}: {e}")
            return ""

    def get_file_content(self, file_path: str, revision: str = 'HEAD') -> str:
        try:
            result = self._run_git(['show', f'{revision}:{file_path}'])
            return result.stdout
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to get content for {file_path}@{revision}: {e}")
            return ""

    def get_current_branch(self) -> str:
        try:
            result = self._run_git(['branch', '--show-current'])
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return "unknown"

    def get_commit_hash(self, ref: str = 'HEAD') -> str:
        try:
            result = self._run_git(['rev-parse', ref])
            return result.stdout.strip()
        except subprocess.CalledProcessError:
            return ""

    def get_files_from_commit(self, commit: str) -> List[str]:
        try:
            result = self._run_git(['diff-tree', '--no-commit-id', '--name-only', '-r', commit])
            files = [f.strip() for f in result.stdout.strip().split('\n') if f.strip()]
            return files
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Failed to get files from commit {commit}: {e}")
            return []

    def get_staged_file_content(self, file_path: str) -> Optional[str]:
        try:
            result = self._run_git(['show', f':{file_path}'])
            return result.stdout
        except subprocess.CalledProcessError as e:
            self.logger.warning(f"Failed to get staged content for {file_path}: {e}")
            return None

    def get_working_dir_file_content(self, file_path: str) -> Optional[str]:
        full_path = os.path.join(self.git_root, file_path)
        if os.path.exists(full_path):
            with open(full_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        return None

    def filter_files_by_pattern(self, files: List[str], include_patterns: List[str] = None,
                                 exclude_patterns: List[str] = None) -> List[str]:
        if not include_patterns and not exclude_patterns:
            return files

        filtered = []
        for f in files:
            if include_patterns:
                if not any(self._match_pattern(f, p) for p in include_patterns):
                    continue

            if exclude_patterns:
                if any(self._match_pattern(f, p) for p in exclude_patterns):
                    continue

            filtered.append(f)

        return filtered

    def _match_pattern(self, file_path: str, pattern: str) -> bool:
        import fnmatch
        return fnmatch.fnmatch(os.path.basename(file_path), pattern)


def get_staged_files() -> List[str]:
    return GitUtils().get_staged_files()


def get_changed_files(since: str = 'HEAD~1') -> List[str]:
    return GitUtils().get_all_changed_files(since)