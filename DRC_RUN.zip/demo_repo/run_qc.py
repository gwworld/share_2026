#!/usr/bin/env python3
"""
run_qc.py - Demo QC execution script
Simulates QC process and validates generated files
Compatible with Python 3.9+
"""

import os
import sys
import argparse
import subprocess
from pathlib import Path
from typing import List, Tuple


def run_qc_on_file(input_file: str, output_dir: str, config: str = None) -> Tuple[bool, str]:
    """Run QC on a single file"""
    input_path = Path(input_file)
    input_name = input_path.stem

    expected_output = Path(output_dir) / f"File_New_{input_name}.v"

    if not expected_output.exists():
        return False, f"Output file not found: {expected_output}"

    with open(expected_output, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()

    if "Verification: PASS" in content:
        return True, f"QC passed for {input_file}"
    else:
        return False, f"QC failed for {input_file}"


def run_qc_batch(input_files: List[str], output_dir: str, config: str = None) -> dict:
    """Run QC on multiple files"""
    results = {
        'passed': [],
        'failed': [],
        'total': len(input_files)
    }

    for input_file in input_files:
        success, message = run_qc_on_file(input_file, output_dir, config)
        if success:
            results['passed'].append(input_file)
            print(f"[PASS] {message}")
        else:
            results['failed'].append(input_file)
            print(f"[FAIL] {message}")

    return results


def main():
    parser = argparse.ArgumentParser(description='Run QC on generated files')
    parser.add_argument('--input', required=True, help='Input files (space separated)')
    parser.add_argument('--output', required=True, help='Output directory path')
    parser.add_argument('--config', help='Config file path (optional)')

    args = parser.parse_args()

    input_files = args.input.split()
    output_dir = args.output
    config = args.config

    if not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)

    print(f"Running QC on {len(input_files)} files...")
    print(f"Output directory: {output_dir}")

    results = run_qc_batch(input_files, output_dir, config)

    print("\n" + "=" * 50)
    print(f"QC Summary: {results['passed']}/{results['total']} passed")
    print("=" * 50)

    if results['failed']:
        return 1

    return 0


if __name__ == '__main__':
    sys.exit(main())