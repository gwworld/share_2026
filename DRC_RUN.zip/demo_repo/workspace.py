import os
import shutil
import uuid
from pathlib import Path
from typing import List, Optional, Dict
from datetime import datetime
from logger import get_logger


class WorkspaceManager:
    def __init__(self, workspace_root: str, keep_files: bool = False):
        self.workspace_root = Path(workspace_root)
        self.keep_files = keep_files
        self.current_workspace: Optional[Path] = None
        self.logger = get_logger('Workspace')

    def create_workspace(self, prefix: str = "qc") -> Path:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        unique_id = str(uuid.uuid4())[:8]
        workspace_name = f"{prefix}_{timestamp}_{unique_id}"
        self.current_workspace = self.workspace_root / workspace_name
        self.current_workspace.mkdir(parents=True, exist_ok=True)

        (self.current_workspace / "input").mkdir(exist_ok=True)
        (self.current_workspace / "output").mkdir(exist_ok=True)
        (self.current_workspace / "logs").mkdir(exist_ok=True)

        self.logger.info(f"Created workspace: {self.current_workspace}")
        return self.current_workspace

    def get_workspace(self) -> Optional[Path]:
        return self.current_workspace

    def copy_files(self, files: List[str], source_root: str, preserve_structure: bool = True) -> List[str]:
        if not self.current_workspace:
            raise RuntimeError("Workspace not created. Call create_workspace() first.")

        copied_files = []
        input_dir = self.current_workspace / "input"

        for file_path in files:
            source_path = Path(source_root) / file_path
            if not source_path.exists():
                self.logger.warning(f"Source file not found: {source_path}")
                continue

            if preserve_structure:
                dest_path = input_dir / file_path
                dest_path.parent.mkdir(parents=True, exist_ok=True)
            else:
                dest_path = input_dir / Path(file_path).name

            try:
                shutil.copy2(source_path, dest_path)
                copied_files.append(str(dest_path))
                self.logger.debug(f"Copied: {file_path}")
            except Exception as e:
                self.logger.error(f"Failed to copy {file_path}: {e}")

        self.logger.info(f"Copied {len(copied_files)} files to workspace")
        return copied_files

    def archive_output(self, archive_dir: str = None) -> Path:
        if not self.current_workspace:
            raise RuntimeError("Workspace not created.")

        output_dir = self.current_workspace / "output"

        if archive_dir:
            archive_path = Path(archive_dir)
        else:
            archive_path = self.workspace_root / "archives" / self.current_workspace.name

        archive_path.parent.mkdir(parents=True, exist_ok=True)

        if archive_path.exists():
            shutil.rmtree(archive_path)

        shutil.copytree(output_dir, archive_path)
        self.logger.info(f"Archived output to: {archive_path}")
        return archive_path

    def cleanup(self):
        if not self.current_workspace:
            return

        if self.keep_files:
            self.logger.info(f"Keeping workspace: {self.current_workspace}")
            return

        try:
            shutil.rmtree(self.current_workspace)
            self.logger.info(f"Cleaned up workspace: {self.current_workspace}")
        except Exception as e:
            self.logger.error(f"Failed to cleanup workspace: {e}")

        self.current_workspace = None

    def get_file_path(self, file_name: str, subdir: str = "input") -> Path:
        if not self.current_workspace:
            raise RuntimeError("Workspace not created.")
        return self.current_workspace / subdir / file_name

    def get_output_path(self, file_name: str) -> Path:
        return self.get_file_path(file_name, "output")

    def list_workspace_files(self, subdir: str = None) -> List[str]:
        if not self.current_workspace:
            return []

        target_dir = self.current_workspace / subdir if subdir else self.current_workspace

        if not target_dir.exists():
            return []

        files = []
        for root, _, files_list in os.walk(target_dir):
            for f in files_list:
                rel_path = os.path.relpath(os.path.join(root, f), target_dir)
                files.append(rel_path)

        return files

    def write_workspace_file(self, content: str, file_name: str, subdir: str = "input") -> Path:
        if not self.current_workspace:
            raise RuntimeError("Workspace not created.")

        file_path = self.current_workspace / subdir / file_name
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)

        self.logger.debug(f"Wrote file: {file_path}")
        return file_path


class WorkspaceContext:
    def __init__(self, workspace_manager: WorkspaceManager):
        self.wm = workspace_manager

    def __enter__(self):
        return self.wm

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type is not None:
            self.wm.keep_files = True
            self.wm.logger.error(f"Error occurred, keeping workspace for debugging")
        self.wm.cleanup()


def create_workspace(workspace_root: str, prefix: str = "qc") -> tuple[Path, WorkspaceManager]:
    wm = WorkspaceManager(workspace_root)
    workspace = wm.create_workspace(prefix)
    return workspace, wm
