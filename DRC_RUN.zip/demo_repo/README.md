# Regression QC System - 使用指南

## 快速开始

### 1. 安装依赖

```bash
pip install pyyaml requests
```

### 2. 配置

编辑 `config.yaml` 文件：

```yaml
workspace: /tmp/regression_qc

lsf:
  queue: normal
  max_jobs: 50
  timeout: 3600

golden:
  path: /central/golden_data
  diff_mode: text
```

### 3. 安装 Git Hooks

```bash
python install.py
```

### 4. 运行测试

```bash
python main.py --verbose
```

## 使用方法

### 提交代码（自动触发 QC）

```bash
git add .
git commit -m "your changes"
```

### 推送代码（自动触发 QC）

```bash
git push origin main
```

### 绕过 Hook

```bash
git commit --no-verify -m "your message"
git push --no-verify origin main
```

### 调试模式

```bash
python main.py --verbose --keep-workspace
```

## 输出示例

### 通过情况

```
============================================================
QC SUMMARY
============================================================
Total Files: 10
Matched: 10
Different: 0
Missing (new): 0
Missing (golden): 0
============================================================
RESULT: PASS
============================================================
```

### 失败情况

```
============================================================
DIFF CHECK REPORT - 2024-01-15T10:30:00
============================================================

Summary:
  Total Files:   10
  Matched:       8
  Different:     2
  Missing (new): 0
  Missing (gold):0
  Result:        FAIL

----------------------------------------------------------------
DETAILED DIFFERENCES:
----------------------------------------------------------------

File: output/module_a.out
Status: DIFF
Match: 95.5%
Golden lines: 100, New lines: 102
Golden hash: a1b2c3d4...
New hash:    e5f6g7h8...

Diff:
  @@ -10,7 +10,9 @@
  -    value = 0;
  +    value = 1;
  +    // Added comment

QC FAILED - Commit blocked
```

## 故障排查

### 查看日志

```bash
tail -f logs/qc.log
```

### 查看工作空间

```bash
ls /tmp/regression_qc/qc_*
```

### 重新运行特定文件

```bash
python main.py --files file1.v file2.v
```

## 配置文件详解

| 参数 | 说明 | 默认值 |
|------|------|--------|
| workspace | 临时工作目录 | /tmp/regression_qc |
| lsf.queue | LSF队列 | normal |
| lsf.max_jobs | 最大并发任务数 | 50 |
| golden.path | Golden结果路径 | /central/golden_data |
| golden.diff_mode | 对比模式 (text/hash) | text |
| golden.ignore_patterns | 忽略文件模式 | [*.tmp, *.log] |

## 项目结构

```
regression_qc/
├── config.yaml          # 主配置文件
├── config/
│   └── split.yaml       # QC分组配置
├── hooks/
│   ├── pre-commit       # 提交前Hook
│   └── pre-push         # 推送前Hook
├── main.py              # 主入口
├── logger.py            # 日志模块
├── config_loader.py     # 配置加载
├── git_utils.py         # Git工具
├── workspace.py         # 工作空间管理
├── lsf_runner.py        # LSF任务管理
├── file_generator.py    # 文件生成
├── qc_runner.py         # QC执行
├── diff_checker.py      # Golden对比
└── install.py          # 安装脚本
```
