import os
import hashlib
import fnmatch
import difflib
import json
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from multiprocessing import Pool, cpu_count
from logger import get_logger


@dataclass
class DiffResult:
    file_name: str
    status: str
    diff_lines: List[str] = field(default_factory=list)
    golden_path: Optional[str] = None
    new_path: Optional[str] = None
    golden_hash: Optional[str] = None
    new_hash: Optional[str] = None
    match_percentage: float = 0.0
    line_count_golden: int = 0
    line_count_new: int = 0


@dataclass
class DiffSummary:
    total_files: int = 0
    matched: int = 0
    diff: int = 0
    missing_in_new: int = 0
    missing_in_golden: int = 0
    diff_results: List[DiffResult] = field(default_factory=list)
    pass_: bool = True
    timestamp: str = ""


class DiffChecker:
    def __init__(self, golden_path: str, diff_mode: str = "text",
                 ignore_patterns: List[str] = None, strict_mode: bool = True,
                 max_workers: int = None):
        self.golden_path = Path(golden_path)
        self.diff_mode = diff_mode
        self.ignore_patterns = ignore_patterns or []
        self.strict_mode = strict_mode
        self.max_workers = max_workers or max(1, cpu_count() - 1)
        self.logger = get_logger('DiffChecker')

    def check(self, new_path: str, output_report: str = None) -> DiffSummary:
        new_path = Path(new_path)

        if not new_path.exists():
            raise FileNotFoundError(f"New results path does not exist: {new_path}")

        if not self.golden_path.exists():
            raise FileNotFoundError(f"Golden path does not exist: {self.golden_path}")

        self.logger.info(f"Starting diff check: {new_path} vs {self.golden_path}")

        new_files = self._get_file_list(new_path)
        golden_files = self._get_file_list(self.golden_path)

        self.logger.info(f"Found {len(new_files)} new files, {len(golden_files)} golden files")

        if self.max_workers > 1 and len(new_files) > 10:
            summary = self._check_parallel(new_files, golden_files, new_path)
        else:
            summary = self._check_sequential(new_files, golden_files, new_path)

        summary.timestamp = datetime.now().isoformat()
        summary.pass_ = (summary.diff == 0 and summary.missing_in_golden == 0)

        if output_report:
            self._save_report(summary, output_report)

        self.logger.info(f"Diff check complete: {summary.matched}/{summary.total_files} matched, "
                        f"{summary.diff} diffs, {summary.missing_in_new} missing")

        return summary

    def _get_file_list(self, base_path: Path) -> Dict[str, Path]:
        files = {}

        for root, _, filenames in os.walk(base_path):
            for filename in filenames:
                if self._should_ignore(filename):
                    continue

                full_path = Path(root) / filename
                rel_path = str(full_path.relative_to(base_path))
                files[rel_path] = full_path

        return files

    def _should_ignore(self, filename: str) -> bool:
        for pattern in self.ignore_patterns:
            if fnmatch.fnmatch(filename, pattern):
                return True
        return False

    def _check_sequential(self, new_files: Dict[str, Path],
                         golden_files: Dict[str, Path],
                         new_path: Path) -> DiffSummary:
        summary = DiffSummary()

        all_files = set(new_files.keys()) | set(golden_files.keys())
        summary.total_files = len(all_files)

        for rel_path in sorted(all_files):
            result = self._compare_files(
                rel_path,
                new_files.get(rel_path),
                golden_files.get(rel_path),
                new_path
            )
            summary.diff_results.append(result)

            if result.status == "matched":
                summary.matched += 1
            elif result.status == "diff":
                summary.diff += 1
            elif result.status == "missing_in_new":
                summary.missing_in_golden += 1
            elif result.status == "missing_in_golden":
                summary.missing_in_new += 1

        return summary

    def _check_parallel(self, new_files: Dict[str, Path],
                       golden_files: Dict[str, Path],
                       new_path: Path) -> DiffSummary:
        summary = DiffSummary()

        all_files = list(set(new_files.keys()) | set(golden_files.keys()))
        summary.total_files = len(all_files)

        tasks = [(rel_path, new_files.get(rel_path), golden_files.get(rel_path), new_path)
                 for rel_path in all_files]

        with Pool(processes=self.max_workers) as pool:
            results = pool.starmap(self._compare_files_task, tasks)

        for result in results:
            summary.diff_results.append(result)

            if result.status == "matched":
                summary.matched += 1
            elif result.status == "diff":
                summary.diff += 1
            elif result.status == "missing_in_new":
                summary.missing_in_golden += 1
            elif result.status == "missing_in_golden":
                summary.missing_in_new += 1

        return summary

    @staticmethod
    def _compare_files_task(rel_path: str, new_file: Optional[Path],
                            golden_file: Optional[Path], new_path: Path) -> DiffResult:
        checker = DiffChecker.__new__(DiffChecker)
        return checker._compare_files(rel_path, new_file, golden_file, new_path)

    def _compare_files(self, rel_path: str, new_file: Optional[Path],
                      golden_file: Optional[Path], new_path: Path) -> DiffResult:
        result = DiffResult(file_name=rel_path, status="unknown")

        if new_file is None:
            result.status = "missing_in_new"
            result.golden_path = str(golden_file)
            self.logger.warning(f"File missing in new results: {rel_path}")
            return result

        if golden_file is None:
            result.status = "missing_in_golden"
            result.new_path = str(new_file)
            self.logger.warning(f"File missing in golden: {rel_path}")
            return result

        result.new_path = str(new_file)
        result.golden_path = str(golden_file)

        if self.diff_mode == "hash":
            return self._compare_by_hash(result, new_file, golden_file)
        else:
            return self._compare_by_text(result, new_file, golden_file)

    def _compare_by_hash(self, result: DiffResult, new_file: Path, golden_file: Path) -> DiffResult:
        result.new_hash = self._compute_hash(new_file)
        result.golden_hash = self._compute_hash(golden_file)

        if result.new_hash == result.golden_hash:
            result.status = "matched"
            result.match_percentage = 100.0
        else:
            result.status = "diff"
            result.match_percentage = 0.0

        return result

    def _compare_by_text(self, result: DiffResult, new_file: Path, golden_file: Path) -> DiffResult:
        try:
            with open(new_file, 'r', encoding='utf-8', errors='ignore') as f:
                new_content = f.read()
            with open(golden_file, 'r', encoding='utf-8', errors='ignore') as f:
                golden_content = f.read()
        except Exception as e:
            self.logger.error(f"Error reading files for comparison: {e}")
            result.status = "error"
            return result

        result.line_count_new = len(new_content.splitlines())
        result.line_count_golden = len(golden_content.splitlines())

        new_lines = new_content.splitlines()
        golden_lines = golden_content.splitlines()

        diff = list(difflib.unified_diff(
            golden_lines, new_lines,
            fromfile=f"a/{result.file_name}",
            tofile=f"b/{result.file_name}",
            lineterm=''
        ))

        if not diff:
            result.status = "matched"
            result.match_percentage = 100.0
        else:
            result.diff_lines = diff
            result.match_percentage = self._calculate_match_percentage(golden_lines, new_lines)

            if result.match_percentage >= 99.0:
                result.status = "matched"
            else:
                result.status = "diff"

        result.new_hash = self._compute_hash(new_file)
        result.golden_hash = self._compute_hash(golden_file)

        return result

    def _calculate_match_percentage(self, golden_lines: List[str], new_lines: List[str]) -> float:
        if not golden_lines and not new_lines:
            return 100.0
        if not golden_lines or not new_lines:
            return 0.0

        matcher = difflib.SequenceMatcher(None, golden_lines, new_lines)
        return round(matcher.ratio() * 100, 2)

    def _compute_hash(self, file_path: Path) -> str:
        hasher = hashlib.sha256()
        try:
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    hasher.update(chunk)
            return hasher.hexdigest()
        except Exception as e:
            self.logger.error(f"Failed to compute hash for {file_path}: {e}")
            return ""

    def _save_report(self, summary: DiffSummary, output_path: str):
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(self._format_text_report(summary))

        json_path = output_path.with_suffix('.json')
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(self._to_dict(summary), f, indent=2)

        self.logger.info(f"Reports saved to {output_path} and {json_path}")

    def _format_text_report(self, summary: DiffSummary) -> str:
        lines = []
        lines.append("=" * 80)
        lines.append(f"DIFF CHECK REPORT - {summary.timestamp}")
        lines.append("=" * 80)
        lines.append("")
        lines.append(f"Summary:")
        lines.append(f"  Total Files:   {summary.total_files}")
        lines.append(f"  Matched:       {summary.matched}")
        lines.append(f"  Different:     {summary.diff}")
        lines.append(f"  Missing (new): {summary.missing_in_new}")
        lines.append(f"  Missing (gold):{summary.missing_in_golden}")
        lines.append(f"  Result:        {'PASS' if summary.pass_ else 'FAIL'}")
        lines.append("")
        lines.append("-" * 80)

        if summary.diff > 0 or summary.missing_in_new > 0 or summary.missing_in_golden > 0:
            lines.append("DETAILED DIFFERENCES:")
            lines.append("-" * 80)

            for result in summary.diff_results:
                if result.status != "matched":
                    lines.append(f"\nFile: {result.file_name}")
                    lines.append(f"Status: {result.status.upper()}")

                    if result.status == "diff":
                        lines.append(f"Match: {result.match_percentage}%")
                        lines.append(f"Golden lines: {result.line_count_golden}, New lines: {result.line_count_new}")
                        lines.append(f"Golden hash: {result.golden_hash[:16]}...")
                        lines.append(f"New hash:    {result.new_hash[:16]}...")

                        if result.diff_lines:
                            lines.append("Diff:")
                            for line in result.diff_lines[:50]:
                                lines.append(f"  {line}")
                            if len(result.diff_lines) > 50:
                                lines.append(f"  ... ({len(result.diff_lines) - 50} more lines)")

                    elif result.status == "missing_in_golden":
                        lines.append(f"New file: {result.new_path}")

                    elif result.status == "missing_in_new":
                        lines.append(f"Golden file: {result.golden_path}")

                    lines.append("")

        lines.append("=" * 80)

        return "\n".join(lines)

    def _to_dict(self, summary: DiffSummary) -> dict:
        return {
            "timestamp": summary.timestamp,
            "total_files": summary.total_files,
            "matched": summary.matched,
            "diff": summary.diff,
            "missing_in_new": summary.missing_in_new,
            "missing_in_golden": summary.missing_in_golden,
            "pass": summary.pass_,
            "results": [
                {
                    "file": r.file_name,
                    "status": r.status,
                    "match_percentage": r.match_percentage,
                    "golden_hash": r.golden_hash[:16] + "..." if r.golden_hash else None,
                    "new_hash": r.new_hash[:16] + "..." if r.new_hash else None
                }
                for r in summary.diff_results
            ]
        }


class ColoredDiffChecker(DiffChecker):
    def _format_text_report(self, summary: DiffSummary) -> str:
        RESET = "\033[0m"
        GREEN = "\033[32m"
        RED = "\033[31m"
        YELLOW = "\033[33m"
        BLUE = "\033[34m"

        lines = []
        lines.append(f"{BLUE}{'=' * 80}{RESET}")
        lines.append(f"{BLUE}DIFF CHECK REPORT - {summary.timestamp}{RESET}")
        lines.append(f"{BLUE}{'=' * 80}{RESET}")
        lines.append("")

        status_color = GREEN if summary.pass_ else RED
        result_text = "PASS" if summary.pass_ else "FAIL"

        lines.append(f"Summary:")
        lines.append(f"  Total Files:   {summary.total_files}")
        lines.append(f"  {GREEN}Matched:       {summary.matched}{RESET}")
        lines.append(f"  {RED}Different:     {summary.diff}{RESET}")
        lines.append(f"  {YELLOW}Missing (new): {summary.missing_in_new}{RESET}")
        lines.append(f"  {YELLOW}Missing (gold):{summary.missing_in_golden}{RESET}")
        lines.append(f"  Result:        {status_color}{result_text}{RESET}")
        lines.append("")
        lines.append(f"{BLUE}{'-' * 80}{RESET}")

        if summary.diff > 0 or summary.missing_in_new > 0 or summary.missing_in_golden > 0:
            lines.append(f"{RED}DETAILED DIFFERENCES:{RESET}")
            lines.append(f"{BLUE}{'-' * 80}{RESET}")

            for result in summary.diff_results:
                if result.status != "matched":
                    if result.status == "diff":
                        color = RED
                    elif result.status == "missing_in_golden":
                        color = YELLOW
                    else:
                        color = YELLOW

                    lines.append(f"\n{color}File: {result.file_name}{RESET}")
                    lines.append(f"{color}Status: {result.status.upper()}{RESET}")

                    if result.status == "diff":
                        lines.append(f"Match: {result.match_percentage}%")
                        if result.diff_lines:
                            lines.append("Diff:")
                            for line in result.diff_lines[:30]:
                                if line.startswith('+'):
                                    lines.append(f"  {GREEN}{line}{RESET}")
                                elif line.startswith('-'):
                                    lines.append(f"  {RED}{line}{RESET}")
                                elif line.startswith('@@'):
                                    lines.append(f"  {YELLOW}{line}{RESET}")
                                else:
                                    lines.append(f"  {line}")

        lines.append(f"{BLUE}{'=' * 80}{RESET}")

        return "\n".join(lines)


class HTMLDiffChecker(DiffChecker):
    def generate_html_report(self, summary: DiffSummary, output_path: str):
        html = self._generate_html(summary)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html)

        self.logger.info(f"HTML report saved to {output_path}")

    def _generate_html(self, summary: DiffSummary) -> str:
        status_color = "green" if summary.pass_ else "red"

        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>QC Diff Report</title>
    <style>
        body {{ font-family: monospace; margin: 20px; background: #1e1e1e; color: #d4d4d4; }}
        h1 {{ color: #569cd6; }}
        .summary {{ background: #2d2d2d; padding: 15px; border-radius: 5px; margin: 20px 0; }}
        .pass {{ color: #4ec9b0; }}
        .fail {{ color: #f14c4c; }}
        .diff {{ color: #dcdcaa; }}
        .missing {{ color: #ce9178; }}
        table {{ border-collapse: collapse; width: 100%; margin: 20px 0; }}
        th, td {{ border: 1px solid #3e3e42; padding: 10px; text-align: left; }}
        th {{ background: #2d2d2d; color: #569cd6; }}
        .diff-content {{ background: #1e1e1e; padding: 10px; overflow-x: auto; }}
        .add {{ color: #4ec9b0; }}
        .remove {{ color: #f14c4c; }}
        .info {{ color: #9cdcfe; }}
    </style>
</head>
<body>
    <h1>QC Diff Report</h1>
    <div class="summary">
        <p><strong>Generated:</strong> {summary.timestamp}</p>
        <p><strong>Total Files:</strong> {summary.total_files}</p>
        <p class="pass">Matched: {summary.matched}</p>
        <p class="diff">Different: {summary.diff}</p>
        <p class="missing">Missing in New: {summary.missing_in_new}</p>
        <p class="missing">Missing in Golden: {summary.missing_in_golden}</p>
        <p class="{status_color}"><strong>Result: {"PASS" if summary.pass_ else "FAIL"}</strong></p>
    </div>
"""

        diff_results = [r for r in summary.diff_results if r.status != "matched"]
        if diff_results:
            html += """
    <h2>Different Files</h2>
    <table>
        <tr>
            <th>File</th>
            <th>Status</th>
            <th>Match %</th>
            <th>Details</th>
        </tr>
"""
            for result in diff_results:
                status_class = "diff" if result.status == "diff" else "missing"
                html += f"""
        <tr>
            <td>{result.file_name}</td>
            <td class="{status_class}">{result.status}</td>
            <td>{result.match_percentage}%</td>
            <td>
"""
                if result.diff_lines:
                    html += "<div class='diff-content'><pre>"
                    for line in result.diff_lines[:50]:
                        if line.startswith('+'):
                            html += f"<span class='add'>{line}</span>\n"
                        elif line.startswith('-'):
                            html += f"<span class='remove'>{line}</span>\n"
                        elif line.startswith('@@'):
                            html += f"<span class='info'>{line}</span>\n"
                        else:
                            html += f"{line}\n"
                    html += "</pre></div>"
                html += """
            </td>
        </tr>
"""
            html += "    </table>\n"

        html += """
</body>
</html>"""

        return html


def create_diff_checker(config: dict) -> DiffChecker:
    golden_config = config.get('golden', {})

    diff_mode = golden_config.get('diff_mode', 'text')
    ignore_patterns = golden_config.get('ignore_patterns', [])
    strict_mode = golden_config.get('strict_mode', True)

    return DiffChecker(
        golden_path=golden_config.get('path', '/central/golden_data'),
        diff_mode=diff_mode,
        ignore_patterns=ignore_patterns,
        strict_mode=strict_mode
    )