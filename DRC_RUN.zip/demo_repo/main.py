import os
import sys
import argparse
import json
from pathlib import Path
from typing import List, Optional

from config_loader import ConfigLoader, load_config
from logger import QCLogger, get_logger
from git_utils import GitUtils, get_staged_files, get_changed_files
from workspace import WorkspaceManager, WorkspaceContext, create_workspace
from file_generator import FileGenerator, create_file_generator
from qc_runner import QCRunner, create_qc_runner
from diff_checker import DiffChecker, ColoredDiffChecker, HTMLDiffChecker, create_diff_checker


class RegressionQC:
    def __init__(self, config_path: str = None, use_lsf: bool = False,
                 keep_workspace: bool = False, verbose: bool = False):
        self.config_path = config_path
        self.use_lsf = use_lsf
        self.keep_workspace = keep_workspace
        self.verbose = verbose

        self.config = load_config(config_path)
        self.logger = get_logger('RegressionQC')

        QCLogger.get_instance(self.config).setup()

        self.git_utils = GitUtils()
        self.workspace_manager: Optional[WorkspaceManager] = None
        self.diff_checker: Optional[DiffChecker] = None

    def run(self, hook_type: str = "pre-commit") -> int:
        try:
            self.logger.info(f"Starting Regression QC - {hook_type}")

            if not self.git_utils.is_repo():
                self.logger.error("Not a git repository")
                return 1

            changed_files = self._get_changed_files()
            if not changed_files:
                self.logger.info("No changed files to process")
                return 0

            self.logger.info(f"Processing {len(changed_files)} changed files")

            self.workspace_manager = WorkspaceManager(
                self.config['workspace'],
                keep_files=self.keep_workspace
            )
            workspace = self.workspace_manager.create_workspace()

            self.logger.info(f"Workspace created: {workspace}")

            input_files = self.workspace_manager.copy_files(
                changed_files,
                self.git_utils.git_root,
                preserve_structure=True
            )

            if not input_files:
                self.logger.error("No input files copied to workspace")
                return 1

            self._run_file_generation(input_files, workspace)

            self._run_qc(workspace)

            output_files = self.workspace_manager.list_workspace_files("output")
            if not output_files:
                self.logger.error("No output files generated")
                return 1

            golden_path = self.config['golden']['path']
            report_path = workspace / "diff_report.txt"

            self.diff_checker = create_diff_checker(self.config)

            if self.verbose:
                self.diff_checker = ColoredDiffChecker(
                    golden_path,
                    diff_mode=self.config['golden'].get('diff_mode', 'text'),
                    ignore_patterns=self.config['golden'].get('ignore_patterns', []),
                    strict_mode=self.config['golden'].get('strict_mode', True)
                )

            summary = self.diff_checker.check(
                str(workspace / "output"),
                output_report=str(report_path)
            )

            self._print_summary(summary)

            if self.config.get('notification', {}).get('enabled'):
                self._send_notification(summary)

            if not self.keep_workspace:
                self.workspace_manager.cleanup()

            if summary.pass_:
                self.logger.info("QC PASSED - Proceeding with commit/push")
                return 0
            else:
                self.logger.error("QC FAILED - Blocking commit/push")
                self.logger.error(f"Diff report: {report_path}")
                return 1

        except Exception as e:
            self.logger.exception(f"QC failed with error: {e}")
            if self.workspace_manager and not self.keep_workspace:
                self.workspace_manager.keep_files = True
                self.workspace_manager.cleanup()
            return 1

    def _get_changed_files(self) -> List[str]:
        git_config = self.config.get('git', {})

        if git_config.get('staged_only', False):
            files = self.git_utils.get_staged_files()
        else:
            since = git_config.get('diff_since', 'HEAD~1')
            files = self.git_utils.get_all_changed_files(since)

        exclude_patterns = self.config['golden'].get('ignore_patterns', [])
        if exclude_patterns:
            files = self.git_utils.filter_files_by_pattern(
                files,
                exclude_patterns=exclude_patterns
            )

        return files

    def _run_file_generation(self, input_files: List[str], workspace: Path):
        self.logger.info("Running file generation...")

        generator = create_file_generator(self.config.get('file_generator', {}))

        generated = generator.generate_files(
            input_files,
            workspace,
            use_lsf=self.use_lsf
        )

        self.logger.info(f"Generated {len(generated)} files")

    def _run_qc(self, workspace: Path):
        self.logger.info("Running QC...")

        qc_config = self.config.get('qc', {})
        lsf_config = self.config.get('lsf') if self.use_lsf else None

        runner = create_qc_runner(qc_config, lsf_config)

        output_dir = workspace / "output"
        input_files = [str(f) for f in self.workspace_manager.list_workspace_files("input")]

        runner.run_qc(input_files, workspace, use_lsf=self.use_lsf)

    def _print_summary(self, summary):
        self.logger.info("=" * 60)
        self.logger.info("QC SUMMARY")
        self.logger.info("=" * 60)
        self.logger.info(f"Total Files: {summary.total_files}")
        self.logger.info(f"Matched: {summary.matched}")
        self.logger.info(f"Different: {summary.diff}")
        self.logger.info(f"Missing (new): {summary.missing_in_new}")
        self.logger.info(f"Missing (golden): {summary.missing_in_golden}")
        self.logger.info("=" * 60)

        if summary.pass_:
            self.logger.info("RESULT: PASS")
        else:
            self.logger.error("RESULT: FAIL")

        self.logger.info("=" * 60)

    def _send_notification(self, summary):
        try:
            notification_config = self.config.get('notification', {})

            if notification_config.get('slack_webhook'):
                self._send_slack(summary, notification_config['slack_webhook'])

            if notification_config.get('email_to'):
                self._send_email(summary, notification_config['email_to'])

        except Exception as e:
            self.logger.warning(f"Failed to send notification: {e}")

    def _send_slack(self, summary, webhook_url: str):
        import requests

        status_emoji = ":white_check_mark:" if summary.pass_ else ":x:"
        status_color = "good" if summary.pass_ else "danger"

        payload = {
            "attachments": [{
                "color": status_color,
                "title": f"QC {status_emoji} {'PASSED' if summary.pass_ else 'FAILED'}",
                "fields": [
                    {"title": "Total Files", "value": str(summary.total_files), "short": True},
                    {"title": "Matched", "value": str(summary.matched), "short": True},
                    {"title": "Different", "value": str(summary.diff), "short": True},
                    {"title": "Missing", "value": str(summary.missing_in_new), "short": True},
                ]
            }]
        }

        requests.post(webhook_url, json=payload, timeout=10)

    def _send_email(self, summary, recipients: List[str]):
        import smtplib
        from email.mime.text import MIMEText
        from email.mime.multipart import MIMEMultipart

        email_config = self.config.get('email', {})

        msg = MIMEMultipart()
        msg['From'] = email_config.get('from', 'qc@example.com')
        msg['To'] = ', '.join(recipients)
        msg['Subject'] = f"QC {'PASSED' if summary.pass_ else 'FAILED'} - {summary.timestamp}"

        body = f"""
QC Result: {'PASS' if summary.pass_ else 'FAILED'}

Summary:
- Total Files: {summary.total_files}
- Matched: {summary.matched}
- Different: {summary.diff}
- Missing (new): {summary.missing_in_new}
- Missing (golden): {summary.missing_in_golden}
"""

        msg.attach(MIMEText(body, 'plain'))

        if email_config.get('smtp_server'):
            with smtplib.SMTP(email_config['smtp_server'], email_config.get('smtp_port', 25)) as server:
                if email_config.get('use_tls'):
                    server.starttls()
                if email_config.get('username'):
                    server.login(email_config['username'], email_config['password'])
                server.send_message(msg)


def parse_args():
    parser = argparse.ArgumentParser(
        description='Regression QC System - Git Hook Integration'
    )

    parser.add_argument(
        '--config', '-c',
        default='config.yaml',
        help='Path to configuration file'
    )

    parser.add_argument(
        '--hook', '-t',
        choices=['pre-commit', 'pre-push'],
        default='pre-commit',
        help='Git hook type'
    )

    parser.add_argument(
        '--lsf', '-l',
        action='store_true',
        help='Use LSF for job submission'
    )

    parser.add_argument(
        '--keep-workspace', '-k',
        action='store_true',
        help='Keep workspace for debugging'
    )

    parser.add_argument(
        '--verbose', '-v',
        action='store_true',
        help='Enable verbose/colored output'
    )

    parser.add_argument(
        '--files', '-f',
        nargs='+',
        help='Specific files to process (bypass git)'
    )

    return parser.parse_args()


def main():
    args = parse_args()

    qc = RegressionQC(
        config_path=args.config,
        use_lsf=args.lsf,
        keep_workspace=args.keep_workspace,
        verbose=args.verbose
    )

    if args.files:
        qc.git_utils = GitUtils()
        qc.workspace_manager = WorkspaceManager(qc.config['workspace'])
        workspace = qc.workspace_manager.create_workspace()
        input_files = qc.workspace_manager.copy_files(
            args.files,
            qc.git_utils.git_root
        )
        qc._run_file_generation(input_files, workspace)
        qc._run_qc(workspace)
        return 0

    return qc.run(hook_type=args.hook)


if __name__ == '__main__':
    sys.exit(main())