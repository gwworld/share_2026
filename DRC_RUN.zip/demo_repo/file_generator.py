import os
import subprocess
import time
from typing import List, Optional, Dict, Tuple
from pathlib import Path
from logger import get_logger
from lsf_runner import LSFRunner, LocalRunner


class FileGenerator:
    def __init__(self, script: str = "auto_gen_file.pl", parallel: bool = True,
                 max_workers: int = 10, lsf_config: dict = None):
        self.script = script
        self.parallel = parallel
        self.max_workers = max_workers
        self.logger = get_logger('FileGenerator')

        if lsf_config:
            self.lsf_runner = LSFRunner(
                queue=lsf_config.get('queue', 'normal'),
                max_jobs=lsf_config.get('max_jobs', 50),
                timeout=lsf_config.get('timeout', 3600),
                retry=lsf_config.get('retry', 3),
                project_name=lsf_config.get('project_name', 'regression_qc')
            )
        else:
            self.lsf_runner = None

        self.local_runner = LocalRunner(max_workers=max_workers)

    def generate_files(self, input_files: List[str], workspace: Path,
                       use_lsf: bool = False) -> Dict[str, str]:
        if not input_files:
            self.logger.warning("No input files to generate")
            return {}

        self.logger.info(f"Generating files for {len(input_files)} input files")

        if use_lsf and self.lsf_runner:
            return self._generate_lsf(input_files, workspace)
        else:
            return self._generate_local(input_files, workspace)

    def _generate_local(self, input_files: List[str], workspace: Path) -> Dict[str, str]:
        generated = {}

        if self.parallel:
            commands = [self._build_command([f], workspace) for f in input_files]
            results = self.local_runner.run_parallel(commands)

            for i, (return_code, stdout, stderr) in enumerate(results):
                if return_code == 0:
                    file_name = Path(input_files[i]).stem
                    generated[input_files[i]] = f"File_New_{file_name}"
                    self.logger.debug(f"Generated: File_New_{file_name}")
                else:
                    self.logger.error(f"Failed to generate {input_files[i]}: {stderr}")
        else:
            for f in input_files:
                cmd = self._build_command([f], workspace)
                return_code, stdout, stderr = self.local_runner.run_command(cmd)

                if return_code == 0:
                    file_name = Path(f).stem
                    generated[f] = f"File_New_{file_name}"
                else:
                    self.logger.error(f"Failed to generate {f}: {stderr}")

        return generated

    def _generate_lsf(self, input_files: List[str], workspace: Path) -> Dict[str, str]:
        commands = [self._build_command([f], workspace) for f in input_files]
        job_ids = self.lsf_runner.submit_parallel(commands, job_prefix="gen")

        results = self.lsf_runner.wait_for_jobs(job_ids)

        generated = {}
        for i, job_id in enumerate(job_ids):
            if job_id and results.get(job_id, (False, None))[0]:
                file_name = Path(input_files[i]).stem
                generated[input_files[i]] = f"File_New_{file_name}"
            else:
                self.logger.error(f"LSF job failed for {input_files[i]}")

        return generated

    def _build_command(self, input_files: List[str], workspace: Path) -> str:
        input_str = ",".join(input_files)
        return f"perl {self.script} --input {input_str} --output {workspace}/output"

    def generate_single(self, input_file: str, output_dir: str) -> Optional[str]:
        cmd = f"perl {self.script} --input {input_file} --output {output_dir}"

        return_code, stdout, stderr = self.local_runner.run_command(cmd)

        if return_code == 0:
            file_name = Path(input_file).stem
            output_file = f"File_New_{file_name}"
            self.logger.info(f"Generated: {output_file}")
            return output_file
        else:
            self.logger.error(f"Generation failed: {stderr}")
            return None


class DAGScheduler:
    def __init__(self, file_generator: FileGenerator):
        self.generator = file_generator
        self.logger = get_logger('DAGScheduler')

    def submit_dag(self, tasks: List[Dict]) -> List[str]:
        task_map = {t['id']: t for t in tasks}
        in_degree = {t['id']: 0 for t in tasks}

        for task in tasks:
            for dep in task.get('dependencies', []):
                in_degree[task['id']] += 1

        ready_tasks = [t for t in tasks if in_degree[t['id']] == 0]
        completed = set()
        job_ids = []

        while ready_tasks:
            task = ready_tasks.pop(0)

            cmd = task['command']
            job_id = self.generator.lsf_runner.submit_job(
                cmd,
                job_name=task.get('name', f"task_{task['id']}")
            )
            job_ids.append(job_id)

            completed.add(task['id'])

            for other_task in tasks:
                if other_task['id'] not in completed:
                    in_degree[other_task['id']] -= 1
                    if in_degree[other_task['id']] == 0:
                        ready_tasks.append(other_task)

        return job_ids


def create_file_generator(config: dict) -> FileGenerator:
    return FileGenerator(
        script=config.get('script', 'auto_gen_file.pl'),
        parallel=config.get('parallel', True),
        max_workers=config.get('max_workers', 10),
        lsf_config=config.get('lsf')
    )