import os
import yaml
from pathlib import Path
from typing import Any, Dict, Optional
from logger import get_logger


class ConfigLoader:
    _instance: Optional['ConfigLoader'] = None
    _config: Dict[str, Any] = {}

    def __init__(self, config_path: str = None):
        self.config_path = config_path or self._find_config()
        self.logger = get_logger('ConfigLoader')

    @classmethod
    def get_instance(cls, config_path: str = None) -> 'ConfigLoader':
        if cls._instance is None:
            cls._instance = cls(config_path)
        return cls._instance

    def _find_config(self) -> str:
        possible_paths = [
            Path.cwd() / 'config.yaml',
            Path.cwd() / 'regression_qc' / 'config.yaml',
            Path(__file__).parent / 'config.yaml',
            Path.home() / '.regression_qc' / 'config.yaml',
        ]

        for path in possible_paths:
            if path.exists():
                self.logger.debug(f"Found config at: {path}")
                return str(path)

        default_path = Path.cwd() / 'config.yaml'
        self.logger.warning(f"No config found, using default: {default_path}")
        return str(default_path)

    def load(self, config_path: str = None) -> Dict[str, Any]:
        if config_path:
            self.config_path = config_path

        if not self.config_path:
            raise ValueError("No config path specified")

        config_file = Path(self.config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Config file not found: {self.config_path}")

        self.logger.info(f"Loading config from: {self.config_path}")

        with open(config_file, 'r', encoding='utf-8') as f:
            self._config = yaml.safe_load(f)

        self._apply_defaults()
        self._validate()

        self.logger.info("Config loaded successfully")
        return self._config

    def _apply_defaults(self):
        defaults = {
            'workspace': '/tmp/regression_qc',
            'lsf': {
                'queue': 'normal',
                'max_jobs': 50,
                'timeout': 3600,
                'retry': 3,
                'project_name': 'regression_qc'
            },
            'qc': {
                'script': 'run_qc.py',
                'config_split': 'config/split.yaml',
                'results_dir': 'results',
                'log_dir': 'logs'
            },
            'golden': {
                'path': '/central/golden_data',
                'diff_mode': 'text',
                'ignore_patterns': ['*.tmp', '*.log', '*.swp'],
                'strict_mode': True
            },
            'file_generator': {
                'script': 'auto_gen_file.pl',
                'parallel': True,
                'max_workers': 10
            },
            'git': {
                'hooks_dir': '.git/hooks',
                'staged_only': False,
                'diff_since': 'HEAD~1'
            },
            'notification': {
                'enabled': False,
                'slack_webhook': '',
                'email_to': []
            },
            'logging': {
                'level': 'INFO',
                'file': 'logs/qc.log',
                'console': True,
                'format': '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            },
            'cache': {
                'enabled': True,
                'cache_dir': '.qc_cache',
                'ttl': 86400
            }
        }

        for key, value in defaults.items():
            if key not in self._config:
                self._config[key] = value

    def _validate(self):
        required_keys = ['workspace', 'golden', 'qc']
        for key in required_keys:
            if key not in self._config:
                raise ValueError(f"Missing required config key: {key}")

        if 'path' not in self._config.get('golden', {}):
            raise ValueError("Missing golden.path in config")

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split('.')
        value = self._config

        for k in keys:
            if isinstance(value, dict):
                value = value.get(k)
                if value is None:
                    return default
            else:
                return default

        return value

    def get_all(self) -> Dict[str, Any]:
        return self._config.copy()

    def reload(self) -> Dict[str, Any]:
        return self.load()


def load_config(config_path: str = None) -> Dict[str, Any]:
    loader = ConfigLoader.get_instance(config_path)
    return loader.load()
