import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional


class ColoredFormatter(logging.Formatter):
    COLORS = {
        'DEBUG': '\033[36m',
        'INFO': '\033[32m',
        'WARNING': '\033[33m',
        'ERROR': '\033[31m',
        'CRITICAL': '\033[35m',
        'RESET': '\033[0m'
    }

    def format(self, record):
        if hasattr(sys.stderr, 'isatty') and sys.stderr.isatty():
            levelname = record.levelname
            if levelname in self.COLORS:
                record.levelname = f"{self.COLORS[levelname]}{levelname}{self.COLORS['RESET']}"
        return super().format(record)


class QCLogger:
    _instance: Optional['QCLogger'] = None

    def __init__(self, config: dict = None):
        self.config = config or {}
        self.logger = logging.getLogger('RegressionQC')
        self.logger.setLevel(getattr(logging, self.config.get('level', 'INFO')))
        self.logger.handlers = []

    @classmethod
    def get_instance(cls, config: dict = None) -> 'QCLogger':
        if cls._instance is None:
            cls._instance = cls(config)
        return cls._instance

    def setup(self):
        log_config = self.config.get('logging', {})
        log_format = log_config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        level = getattr(logging, log_config.get('level', 'INFO'))

        if log_config.get('console', True):
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(level)
            console_formatter = ColoredFormatter(log_format)
            console_handler.setFormatter(console_formatter)
            self.logger.addHandler(console_handler)

        log_file = log_config.get('file')
        if log_file:
            log_path = Path(log_file)
            log_path.parent.mkdir(parents=True, exist_ok=True)
            file_handler = logging.FileHandler(log_file, mode='a', encoding='utf-8')
            file_handler.setLevel(level)
            file_formatter = logging.Formatter(log_format)
            file_handler.setFormatter(file_formatter)
            self.logger.addHandler(file_handler)

        return self.logger

    def debug(self, msg: str, *args, **kwargs):
        self.logger.debug(msg, *args, **kwargs)

    def info(self, msg: str, *args, **kwargs):
        self.logger.info(msg, *args, **kwargs)

    def warning(self, msg: str, *args, **kwargs):
        self.logger.warning(msg, *args, **kwargs)

    def error(self, msg: str, *args, **kwargs):
        self.logger.error(msg, *args, **kwargs)

    def critical(self, msg: str, *args, **kwargs):
        self.logger.critical(msg, *args, **kwargs)

    def exception(self, msg: str, *args, **kwargs):
        self.logger.exception(msg, *args, **kwargs)


def get_logger(name: str = None) -> logging.Logger:
    logger = QCLogger.get_instance()
    if name:
        return logging.getLogger(f'RegressionQC.{name}')
    return logger.setup()
