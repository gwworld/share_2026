#!/usr/bin/env python3
"""
Installation script for Regression QC System Git Hooks
"""

import os
import sys
import shutil
import subprocess

def get_repo_root():
    result = subprocess.run(
        ['git', 'rev-parse', '--show-toplevel'],
        capture_output=True,
        text=True,
        check=True
    )
    return result.stdout.strip()

def install_hooks(repo_root, hooks_dir):
    hooks_path = os.path.join(repo_root, '.git', 'hooks')
    os.makedirs(hooks_path, exist_ok=True)

    source_hooks_dir = os.path.join(hooks_dir, 'pre-commit')
    target_pre_commit = os.path.join(hooks_path, 'pre-commit')

    source_push_hooks_dir = os.path.join(hooks_dir, 'pre-push')
    target_pre_push = os.path.join(hooks_path, 'pre-push')

    if os.path.exists(source_hooks_dir):
        shutil.copy2(source_hooks_dir, target_pre_commit)
        os.chmod(target_pre_commit, 0o755)
        print(f"Installed pre-commit hook: {target_pre_commit}")
    else:
        print(f"Warning: pre-commit hook not found at {source_hooks_dir}")

    if os.path.exists(source_push_hooks_dir):
        shutil.copy2(source_push_hooks_dir, target_pre_push)
        os.chmod(target_pre_push, 0o755)
        print(f"Installed pre-push hook: {target_pre_push}")
    else:
        print(f"Warning: pre-push hook not found at {source_push_hooks_dir}")

    print("\nHooks installed successfully!")
    print("\nTo uninstall, run:")
    print("  rm .git/hooks/pre-commit .git/hooks/pre-push")

def create_python_wrapper(repo_root, qc_dir):
    wrapper_dir = os.path.join(repo_root, 'regression_qc')
    os.makedirs(wrapper_dir, exist_ok=True)

    wrapper_script = os.path.join(wrapper_dir, '__main__.py')

    with open(wrapper_script, 'w') as f:
        f.write("""#!/usr/bin/env python3
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))

from main import main

if __name__ == '__main__':
    main()
""")

    print(f"Created wrapper script: {wrapper_script}")
    return wrapper_script

def verify_dependencies():
    print("\nVerifying dependencies...")

    required_modules = ['yaml', 'requests']

    missing = []
    for module in required_modules:
        try:
            __import__(module)
            print(f"  {module}: OK")
        except ImportError:
            print(f"  {module}: MISSING")
            missing.append(module)

    if missing:
        print(f"\nMissing dependencies: {', '.join(missing)}")
        print(f"Install with: pip install {' '.join(missing)}")
        return False

    return True

def main():
    print("=" * 60)
    print("Regression QC System - Installation")
    print("=" * 60)

    try:
        repo_root = get_repo_root()
        print(f"Repository root: {repo_root}")
    except subprocess.CalledProcessError:
        print("Error: Not a git repository")
        sys.exit(1)

    script_dir = os.path.dirname(os.path.abspath(__file__))
    hooks_dir = os.path.join(script_dir, 'hooks')

    if not os.path.exists(hooks_dir):
        hooks_dir = os.path.join(repo_root, 'regression_qc', 'hooks')

    if not os.path.exists(hooks_dir):
        print(f"Error: Hooks directory not found: {hooks_dir}")
        sys.exit(1)

    if verify_dependencies():
        print("\nAll dependencies verified!")
    else:
        print("\nWarning: Some dependencies missing, but continuing...")

    install_hooks(repo_root, hooks_dir)

    create_python_wrapper(repo_root, script_dir)

    print("\n" + "=" * 60)
    print("Installation complete!")
    print("=" * 60)

    print("\nUsage:")
    print("  git commit -m 'your message'")
    print("  git push origin main")

    print("\nTo bypass hooks:")
    print("  git commit --no-verify -m 'your message'")
    print("  git push --no-verify origin main")

    print("\nTo keep workspace for debugging:")
    print("  Add --keep-workspace flag or set keep_files: true in config")

if __name__ == '__main__':
    main()
