import os
import subprocess
import time
import re
from typing import List, Optional, Dict, Tuple
from pathlib import Path
from dataclasses import dataclass
from logger import get_logger


@dataclass
class LSFJob:
    job_id: str
    command: str
    status: str = "submitted"
    return_code: Optional[int] = None
    output_file: Optional[str] = None
    error_file: Optional[str] = None


class LSFRunner:
    def __init__(self, queue: str = "normal", max_jobs: int = 50, timeout: int = 3600,
                 retry: int = 3, project_name: str = "regression_qc"):
        self.queue = queue
        self.max_jobs = max_jobs
        self.timeout = timeout
        self.retry = retry
        self.project_name = project_name
        self.logger = get_logger('LSFRunner')
        self.jobs: Dict[str, LSFJob] = {}

    def submit_job(self, command: str, job_name: str = None, working_dir: str = None,
                   env_vars: Dict[str, str] = None, output_dir: str = None) -> Optional[str]:
        job_name = job_name or f"qc_{int(time.time())}"

        output_file = os.path.join(output_dir or "/tmp", f"{job_name}.out")
        error_file = os.path.join(output_dir or "/tmp", f"{job_name}.err")

        cmd_parts = [
            "bsub",
            "-q", self.queue,
            "-J", job_name,
            "-o", output_file,
            "-e", error_file,
        ]

        if self.project_name:
            cmd_parts.extend(["-P", self.project_name])

        cmd_parts.append(command)

        env = os.environ.copy()
        if env_vars:
            env.update(env_vars)

        self.logger.info(f"Submitting LSF job: {job_name}")
        self.logger.debug(f"Command: {command}")

        try:
            result = subprocess.run(
                cmd_parts,
                capture_output=True,
                text=True,
                env=env,
                cwd=working_dir
            )

            if result.returncode != 0:
                self.logger.error(f"LSF submit failed: {result.stderr}")
                return None

            job_id = self._extract_job_id(result.stdout)
            if job_id:
                self.jobs[job_id] = LSFJob(
                    job_id=job_id,
                    command=command,
                    output_file=output_file,
                    error_file=error_file
                )
                self.logger.info(f"Job submitted: {job_id}")
                return job_id
            else:
                self.logger.error(f"Failed to extract job ID from: {result.stdout}")
                return None

        except Exception as e:
            self.logger.error(f"Failed to submit job: {e}")
            return None

    def _extract_job_id(self, output: str) -> Optional[str]:
        match = re.search(r'Job <(\d+)>', output)
        if match:
            return match.group(1)
        return None

    def submit_parallel(self, commands: List[str], job_prefix: str = "qc") -> List[Optional[str]]:
        job_ids = []
        for i, cmd in enumerate(commands):
            job_name = f"{job_prefix}_{i}"
            job_id = self.submit_job(cmd, job_name=job_name)
            job_ids.append(job_id)

            if len(job_ids) >= self.max_jobs:
                self.logger.warning(f"Reached max jobs limit: {self.max_jobs}")
                break

        return job_ids

    def get_job_status(self, job_id: str) -> Optional[str]:
        try:
            result = subprocess.run(
                ["bjobs", "-a", "-noheader", job_id],
                capture_output=True,
                text=True
            )

            if result.returncode != 0:
                return None

            for line in result.stdout.strip().split('\n'):
                if line.strip():
                    parts = line.split()
                    if len(parts) >= 3:
                        return parts[2]

            return None

        except Exception as e:
            self.logger.error(f"Failed to get job status: {e}")
            return None

    def wait_for_jobs(self, job_ids: List[str], poll_interval: int = 30,
                      timeout: int = None) -> Dict[str, Tuple[bool, Optional[int]]]:
        timeout = timeout or self.timeout
        results = {}
        start_time = time.time()

        pending_jobs = set(job_ids)

        self.logger.info(f"Waiting for {len(pending_jobs)} jobs to complete")

        while pending_jobs:
            if time.time() - start_time > timeout:
                self.logger.error(f"Timeout waiting for jobs: {timeout}s")
                break

            for job_id in list(pending_jobs):
                status = self.get_job_status(job_id)

                if status is None:
                    job_info = self.jobs.get(job_id)
                    if job_info:
                        results[job_id] = (job_info.return_code == 0 if job_info.return_code is not None else False,
                                          job_info.return_code)
                        pending_jobs.remove(job_id)
                elif status in ['DONE', 'COMPLETED']:
                    results[job_id] = (True, 0)
                    pending_jobs.remove(job_id)
                    self.logger.info(f"Job {job_id} completed successfully")
                elif status in ['EXIT', 'FAILED', 'TERM']:
                    results[job_id] = (False, -1)
                    pending_jobs.remove(job_id)
                    self.logger.error(f"Job {job_id} failed with status: {status}")

            time.sleep(poll_interval)

        for job_id in job_ids:
            if job_id not in results:
                results[job_id] = (False, -1)

        return results

    def cancel_job(self, job_id: str) -> bool:
        try:
            result = subprocess.run(
                ["bkill", job_id],
                capture_output=True,
                text=True
            )
            return result.returncode == 0
        except Exception as e:
            self.logger.error(f"Failed to cancel job {job_id}: {e}")
            return False

    def cancel_all(self) -> int:
        cancelled = 0
        for job_id in self.jobs.keys():
            if self.cancel_job(job_id):
                cancelled += 1
        return cancelled

    def get_job_output(self, job_id: str) -> Tuple[Optional[str], Optional[str]]:
        job_info = self.jobs.get(job_id)
        if not job_info:
            return None, None

        stdout = None
        stderr = None

        if job_info.output_file and os.path.exists(job_info.output_file):
            with open(job_info.output_file, 'r', encoding='utf-8', errors='ignore') as f:
                stdout = f.read()

        if job_info.error_file and os.path.exists(job_info.error_file):
            with open(job_info.error_file, 'r', encoding='utf-8', errors='ignore') as f:
                stderr = f.read()

        return stdout, stderr

    def retry_failed_jobs(self, job_ids: List[str]) -> List[Optional[str]]:
        new_job_ids = []
        for job_id in job_ids:
            job_info = self.jobs.get(job_id)
            if job_info and job_info.return_code != 0:
                new_job_id = self.submit_job(
                    job_info.command,
                    job_name=f"{job_info.command.split()[0]}_retry"
                )
                new_job_ids.append(new_job_id)
        return new_job_ids


class LocalRunner:
    def __init__(self, max_workers: int = 4):
        self.max_workers = max_workers
        self.logger = get_logger('LocalRunner')

    def run_command(self, command: str, cwd: str = None, env: Dict[str, str] = None) -> Tuple[int, str, str]:
        self.logger.debug(f"Running locally: {command}")

        env_vars = os.environ.copy()
        if env:
            env_vars.update(env)

        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=cwd,
                capture_output=True,
                text=True,
                env=env_vars
            )
            return result.returncode, result.stdout, result.stderr
        except Exception as e:
            self.logger.error(f"Command failed: {e}")
            return -1, "", str(e)

    def run_parallel(self, commands: List[str]) -> List[Tuple[int, str, str]]:
        import concurrent.futures

        results = []
        with concurrent.futures.ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = [executor.submit(self.run_command, cmd) for cmd in commands]
            for future in futures:
                results.append(future.result())

        return results