[build-system]
requires = ["setuptools>=45", "wheel"]
build-backend = "setuptools.build_meta"

[project]
name = "branch-sync"
version = "1.0.0"
description = "Git Branch Sync Automation Tool"
readme = "README.md"
requires-python = ">=3.7"
license = {text = "MIT"}
authors = [
    {name = "Branch Sync Team"}
]
keywords = ["git", "branch", "sync", "automation"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3",
    "Programming Language :: Python :: 3.7",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
]

dependencies = [
    "pyyaml>=5.4",
]

[project.scripts]
branch-sync = "branch_sync.cli:main"

[project.urls]
Homepage = "https://github.com/branch-sync/branch-sync"