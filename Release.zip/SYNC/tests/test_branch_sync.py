import pytest
import os
import tempfile
import shutil
import subprocess
import yaml
import json
from pathlib import Path

from branch_sync.config import Config, load_config, create_default_config, RepoConfig, BranchConfig, SyncConfig
from branch_sync.branch_manager import BranchManager
from branch_sync.sync_strategy import SyncStrategy, SyncStatus
from branch_sync.conflict_resolver import ConflictResolver
from branch_sync.executor import BranchSyncWorker, ParallelExecutor, SyncResult
from branch_sync.safety import BackupManager, RollbackManager, DryRunManager


class TestConfig:
    def test_default_config(self):
        config = Config()
        assert config.repo.main_branch == "main"
        assert config.repo.remote == "origin"
        assert config.sync.strategy == "rebase"
        assert config.parallel.max_workers == 10

    def test_save_and_load_yaml(self, tmp_path):
        config_path = tmp_path / "test_config.yaml"
        config = Config()
        config.repo.main_branch = "develop"
        config.repo.remote = "upstream"
        
        from branch_sync.config import save_config
        save_config(config, str(config_path))
        
        loaded = load_config(str(config_path))
        assert loaded.repo.main_branch == "develop"
        assert loaded.repo.remote == "upstream"

    def test_save_and_load_json(self, tmp_path):
        config_path = tmp_path / "test_config.json"
        config = Config()
        config.repo.main_branch = "master"
        
        from branch_sync.config import save_config
        save_config(config, str(config_path))
        
        loaded = load_config(str(config_path))
        assert loaded.repo.main_branch == "master"

    def test_create_default_config(self, tmp_path):
        config_path = tmp_path / "default.yaml"
        create_default_config(str(config_path))
        
        assert config_path.exists()
        loaded = load_config(str(config_path))
        assert loaded.repo.path == "."


class TestGitRepo:
    @pytest.fixture
    def git_repo(self, tmp_path):
        repo_path = tmp_path / "test_repo"
        repo_path.mkdir()
        
        subprocess.run(["git", "init"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=repo_path, capture_output=True)
        
        (repo_path / "README.md").write_text("# Test Repo")
        subprocess.run(["git", "add", "README.md"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=repo_path, capture_output=True)
        
        subprocess.run(["git", "checkout", "-b", "main"], cwd=repo_path, capture_output=True)
        
        yield repo_path
        
        os.chdir(tmp_path)

    def test_init_git_repo(self, git_repo):
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=git_repo,
            capture_output=True
        )
        assert result.returncode == 0


class TestBranchManager:
    @pytest.fixture
    def test_config(self, git_repo):
        config = Config()
        config.repo.path = str(git_repo)
        config.repo.main_branch = "main"
        return config

    @pytest.fixture
    def branch_manager(self, test_config):
        return BranchManager(test_config)

    def test_get_local_branches(self, branch_manager):
        branches = branch_manager.get_local_branches()
        assert "main" in branches

    def test_create_and_list_branches(self, git_repo, branch_manager):
        subprocess.run(["git", "branch", "feature_A"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "branch", "feature_B"], cwd=git_repo, capture_output=True)
        
        branches = branch_manager.get_local_branches()
        assert "feature_A" in branches
        assert "feature_B" in branches

    def test_filter_branches_whitelist(self, git_repo, branch_manager):
        branch_manager.whitelist = ["feature_A"]
        
        subprocess.run(["git", "branch", "feature_A"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "branch", "feature_B"], cwd=git_repo, capture_output=True)
        
        branches = branch_manager.get_local_branches()
        filtered = branch_manager.filter_branches(branches)
        
        assert "feature_A" in filtered
        assert "feature_B" not in filtered

    def test_filter_branches_blacklist(self, git_repo, branch_manager):
        branch_manager.blacklist = ["feature_B"]
        
        subprocess.run(["git", "branch", "feature_A"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "branch", "feature_B"], cwd=git_repo, capture_output=True)
        
        branches = branch_manager.get_local_branches()
        filtered = branch_manager.filter_branches(branches)
        
        assert "feature_A" in filtered
        assert "feature_B" not in filtered

    def test_get_target_branches(self, branch_manager):
        branches = branch_manager.get_target_branches()
        assert "main" not in branches


class TestSyncStrategy:
    @pytest.fixture
    def test_config(self, git_repo):
        config = Config()
        config.repo.path = str(git_repo)
        config.repo.main_branch = "main"
        config.repo.remote = "origin"
        return config

    @pytest.fixture
    def sync_strategy(self, test_config):
        return SyncStrategy(test_config)

    def test_get_current_branch(self, git_repo, sync_strategy):
        branch = sync_strategy._get_current_branch()
        assert branch == "main"

    def test_rebase_strategy(self, git_repo, sync_strategy):
        subprocess.run(["git", "checkout", "-b", "feature_test"], cwd=git_repo, capture_output=True)
        (git_repo / "test.txt").write_text("feature content")
        subprocess.run(["git", "add", "test.txt"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Feature commit"], cwd=git_repo, capture_output=True)
        
        subprocess.run(["git", "checkout", "main"], cwd=git_repo, capture_output=True)
        (git_repo / "main.txt").write_text("main content")
        subprocess.run(["git", "add", "main.txt"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Main commit"], cwd=git_repo, capture_output=True)
        
        subprocess.run(["git", "checkout", "feature_test"], cwd=git_repo, capture_output=True)
        
        status, message, conflicts = sync_strategy._rebase("feature_test", False)
        
        assert status in [SyncStatus.SUCCESS, SyncStatus.CONFLICT]


class TestConflictResolver:
    @pytest.fixture
    def test_config(self, git_repo):
        config = Config()
        config.repo.path = str(git_repo)
        return config

    @pytest.fixture
    def conflict_resolver(self, test_config):
        return ConflictResolver(test_config)

    def test_detect_conflicts_no_conflicts(self, git_repo, conflict_resolver):
        conflicts = conflict_resolver.detect_conflicts()
        assert isinstance(conflicts, list)

    def test_conflict_resolution_main(self, git_repo):
        config = Config()
        config.repo.path = str(git_repo)
        
        resolver = ConflictResolver(config)
        
        subprocess.run(["git", "checkout", "main"], cwd=git_repo, capture_output=True)
        (git_repo / "test.txt").write_text("main version")
        subprocess.run(["git", "add", "test.txt"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Main version"], cwd=git_repo, capture_output=True)
        
        subprocess.run(["git", "checkout", "-b", "conflict_branch"], cwd=git_repo, capture_output=True)
        (git_repo / "test.txt").write_text("branch version")
        subprocess.run(["git", "add", "test.txt"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Branch version"], cwd=git_repo, capture_output=True)
        
        subprocess.run(["git", "checkout", "main"], cwd=git_repo, capture_output=True)
        subprocess.run(["git", "merge", "conflict_branch"], cwd=git_repo, capture_output=True)
        
        conflicts = resolver.detect_conflicts()
        
        assert isinstance(conflicts, list)


class TestParallelExecutor:
    def test_execute_sequential(self, tmp_path):
        config = Config()
        config.parallel.enabled = False
        
        executor = ParallelExecutor(config)
        
        results = executor.execute(
            ["branch1", "branch2", "branch3"],
            lambda b: SyncResult(branch=b, status=SyncStatus.SUCCESS, message="done")
        )
        
        assert len(results) == 3


class TestSafety:
    @pytest.fixture
    def test_config(self, git_repo):
        config = Config()
        config.repo.path = str(git_repo)
        config.safety.dry_run = True
        config.safety.backup_before_sync = True
        config.safety.rollback_on_failure = True
        return config

    def test_dry_run_manager(self, test_config):
        dm = DryRunManager(test_config)
        assert dm.is_dry_run() == True
        
        checks = dm.check_prerequisites()
        assert "git_available" in checks

    def test_backup_manager(self, test_config):
        bm = BackupManager(test_config)
        
        result = bm.create_backup("main")
        assert isinstance(result, str) or result is None

    def test_rollback_manager(self, test_config):
        rm = RollbackManager(test_config)
        assert rm.can_rollback() == True
        
        result = rm.abort_operations()
        assert result == True


class TestReporter:
    def test_generate_report(self):
        config = Config()
        
        from branch_sync.reporter import ReportGenerator
        generator = ReportGenerator(config)
        
        results = [
            SyncResult(branch="branch_A", status=SyncStatus.SUCCESS, message="Success", duration=1.0),
            SyncResult(branch="branch_B", status=SyncStatus.CONFLICT, message="Conflict", conflict_files=["a.txt"], duration=2.0),
            SyncResult(branch="branch_C", status=SyncStatus.FAILED, message="Failed", error="Error", duration=0.5),
        ]
        
        report = generator.generate(results, 10.0)
        
        assert report['summary']['total'] == 3
        assert report['summary']['success'] == 1
        assert report['summary']['conflict'] == 1
        assert report['summary']['failed'] == 1

    def test_save_json_report(self, tmp_path):
        config = Config()
        config.report.output = str(tmp_path / "report.json")
        
        from branch_sync.reporter import ReportGenerator
        generator = ReportGenerator(config)
        
        results = [
            SyncResult(branch="branch_A", status=SyncStatus.SUCCESS, message="Success", duration=1.0),
        ]
        
        report = generator.generate(results, 1.0)
        path = generator.save(report)
        
        assert Path(path).exists()
        
        with open(path) as f:
            loaded = json.load(f)
            assert loaded['summary']['total'] == 1


class TestCLI:
    def test_parser_creation(self):
        from branch_sync.cli import BranchSyncCLI
        cli = BranchSyncCLI()
        parser = cli._create_parser()
        
        assert parser is not None


class TestIntegration:
    @pytest.fixture
    def demo_repo(self, tmp_path):
        repo_path = tmp_path / "demo_repo"
        repo_path.mkdir()
        
        subprocess.run(["git", "init"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "config", "user.email", "test@test.com"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "config", "user.name", "Test User"], cwd=repo_path, capture_output=True)
        
        (repo_path / "README.md").write_text("# Demo Repo")
        subprocess.run(["git", "add", "README.md"], cwd=repo_path, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Initial commit"], cwd=repo_path, capture_output=True)
        
        subprocess.run(["git", "checkout", "-b", "main"], cwd=repo_path, capture_output=True)
        
        subprocess.run(["git", "remote", "add", "origin", str(repo_path)], cwd=repo_path, capture_output=True)
        
        yield repo_path

    def test_full_sync_workflow(self, demo_repo):
        config = Config()
        config.repo.path = str(demo_repo)
        config.repo.main_branch = "main"
        config.repo.remote = "origin"
        config.sync.strategy = "rebase"
        config.sync.auto_push = False
        config.safety.dry_run = True
        
        branch_manager = BranchManager(config)
        branches = branch_manager.get_target_branches()
        
        worker = BranchSyncWorker(config)
        
        subprocess.run(["git", "checkout", "-b", "feature_1"], cwd=demo_repo, capture_output=True)
        (demo_repo / "feature1.txt").write_text("feature 1")
        subprocess.run(["git", "add", "feature1.txt"], cwd=demo_repo, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Feature 1"], cwd=demo_repo, capture_output=True)
        
        branches = branch_manager.get_target_branches()
        
        assert "feature_1" in branches or len(branches) >= 0


if __name__ == "__main__":
    pytest.main([__file__, "-v"])