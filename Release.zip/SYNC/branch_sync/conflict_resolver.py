import subprocess
import logging
import shutil
import fnmatch
from pathlib import Path
from typing import List, Optional
from .config import Config
from .sync_strategy import SyncStatus


logger = logging.getLogger(__name__)


class ConflictResolver:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = str(Path(config.repo.path).resolve())
        self.resolution = config.conflict.resolution
        self.auto_resolve = config.conflict.auto_resolve
        self.rules = config.conflict.rules
    
    def detect_conflicts(self) -> List[str]:
        try:
            result = subprocess.run(
                ['git', 'diff', '--name-only', '--diff-filter=U'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            conflicts = [f.strip() for f in result.stdout.split('\n') if f.strip()]
            logger.info(f"Detected {len(conflicts)} conflict files")
            return conflicts
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to detect conflicts: {e}")
            return []
    
    def get_conflict_details(self, file_path: str) -> dict:
        try:
            result = subprocess.run(
                ['git', 'conflicts', file_path],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            
            if result.returncode != 0:
                result = subprocess.run(
                    ['git', 'show', f':2:{file_path}'],
                    cwd=self.repo_path,
                    capture_output=True,
                    text=True
                )
                main_content = result.stdout if result.returncode == 0 else ""
                
                result = subprocess.run(
                    ['git', 'show', f':3:{file_path}'],
                    cwd=self.repo_path,
                    capture_output=True,
                    text=True
                )
                branch_content = result.stdout if result.returncode == 0 else ""
                
                return {
                    'file': file_path,
                    'main': main_content,
                    'branch': branch_content,
                    'has_conflict': True
                }
            
            return {
                'file': file_path,
                'content': result.stdout,
                'has_conflict': True
            }
        except Exception as e:
            logger.error(f"Failed to get conflict details for {file_path}: {e}")
            return {'file': file_path, 'has_conflict': False}
    
    def resolve_conflict(self, file_path: str, prefer: str = None) -> bool:
        if prefer is None:
            prefer = self._get_preferred_source(file_path)
        
        if prefer == "main":
            return self._accept_main(file_path)
        elif prefer == "branch":
            return self._accept_branch(file_path)
        else:
            logger.warning(f"Unknown preference: {prefer}")
            return False
    
    def _get_preferred_source(self, file_path: str) -> str:
        for rule in self.rules:
            if fnmatch.fnmatch(file_path, rule.file_pattern):
                return rule.prefer
        return self.resolution
    
    def _accept_main(self, file_path: str) -> bool:
        try:
            subprocess.run(
                ['git', 'checkout', '--theirs', file_path],
                cwd=self.repo_path,
                check=True
            )
            subprocess.run(
                ['git', 'add', file_path],
                cwd=self.repo_path,
                check=True
            )
            logger.info(f"Accepted main version for {file_path}")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to accept main version: {e}")
            return False
    
    def _accept_branch(self, file_path: str) -> bool:
        try:
            subprocess.run(
                ['git', 'checkout', '--ours', file_path],
                cwd=self.repo_path,
                check=True
            )
            subprocess.run(
                ['git', 'add', file_path],
                cwd=self.repo_path,
                check=True
            )
            logger.info(f"Accepted branch version for {file_path}")
            return True
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to accept branch version: {e}")
            return False
    
    def auto_resolve_conflicts(self, conflicts: List[str]) -> dict:
        results = {}
        
        for file_path in conflicts:
            success = self.resolve_conflict(file_path)
            results[file_path] = 'resolved' if success else 'failed'
        
        return results
    
    def create_conflict_report(self, conflicts: List[str]) -> dict:
        report = {
            'total_conflicts': len(conflicts),
            'conflicts': []
        }
        
        for file_path in conflicts:
            details = self.get_conflict_details(file_path)
            report['conflicts'].append(details)
        
        return report
    
    def has_conflicts(self) -> bool:
        conflicts = self.detect_conflicts()
        return len(conflicts) > 0