import subprocess
import logging
from pathlib import Path
from typing import List, Optional, Tuple
from enum import Enum

from .config import Config


logger = logging.getLogger(__name__)


class SyncStatus(Enum):
    SUCCESS = "success"
    CONFLICT = "conflict"
    FAILED = "failed"
    SKIPPED = "skipped"


class SyncStrategy:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = str(Path(config.repo.path).resolve())
        self.main_branch = config.repo.main_branch
        self.remote = config.repo.remote
        self.strategy = config.sync.strategy
    
    def sync(self, branch: str, dry_run: bool = False) -> Tuple[SyncStatus, str, List[str]]:
        if self.strategy == "rebase":
            return self._rebase(branch, dry_run)
        elif self.strategy == "merge":
            return self._merge(branch, dry_run)
        elif self.strategy == "cherry-pick":
            return self._cherry_pick(branch, dry_run)
        else:
            return SyncStatus.FAILED, f"Unknown strategy: {self.strategy}", []
    
    def _run_git(self, args: List[str], capture: bool = True) -> subprocess.CompletedProcess:
        try:
            result = subprocess.run(
                args,
                cwd=self.repo_path,
                capture_output=capture,
                text=True,
                check=False
            )
            return result
        except Exception as e:
            logger.error(f"Git command failed: {e}")
            raise
    
    def _rebase(self, branch: str, dry_run: bool) -> Tuple[SyncStatus, str, List[str]]:
        logger.info(f"Rebasing {branch} onto {self.main_branch}")
        
        try:
            self._run_git(['git', 'fetch', self.remote, self.main_branch])
            
            current_branch = self._get_current_branch()
            
            if current_branch != branch:
                self._run_git(['git', 'checkout', branch])
            
            if self.config.git.rebase_autostash:
                result = self._run_git(['git', 'rebase', f'{self.remote}/{self.main_branch}', '--autostash'])
            else:
                result = self._run_git(['git', 'rebase', f'{self.remote}/{self.main_branch}'])
            
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                return SyncStatus.CONFLICT, f"Rebase conflict: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, "Rebase completed successfully", []
            
        except Exception as e:
            return SyncStatus.FAILED, f"Rebase failed: {str(e)}", []
    
    def _merge(self, branch: str, dry_run: bool) -> Tuple[SyncStatus, str, List[str]]:
        logger.info(f"Merging {self.main_branch} into {branch}")
        
        try:
            self._run_git(['git', 'fetch', self.remote, self.main_branch])
            
            current_branch = self._get_current_branch()
            
            if current_branch != branch:
                self._run_git(['git', 'checkout', branch])
            
            self._run_git(['git', 'merge', f'{self.remote}/{self.main_branch}', '--no-edit'])
            
            result = self._run_git(['git', 'merge', f'{self.remote}/{self.main_branch}', '--no-edit'])
            
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                return SyncStatus.CONFLICT, f"Merge conflict: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, "Merge completed successfully", []
            
        except Exception as e:
            return SyncStatus.FAILED, f"Merge failed: {str(e)}", []
    
    def _cherry_pick(self, branch: str, dry_run: bool) -> Tuple[SyncStatus, str, List[str]]:
        logger.info(f"Cherry-picking commits into {branch}")
        
        commits = self.config.sync.cherry_pick_commits
        if not commits:
            return SyncStatus.FAILED, "No commits specified for cherry-pick", []
        
        try:
            current_branch = self._get_current_branch()
            
            if current_branch != branch:
                self._run_git(['git', 'checkout', branch])
            
            for commit in commits:
                result = self._run_git(['git', 'cherry-pick', commit])
                
                if result.returncode != 0:
                    conflicts = self._get_conflict_files()
                    return SyncStatus.CONFLICT, f"Cherry-pick conflict at {commit}: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, f"Cherry-picked {len(commits)} commits", []
            
        except Exception as e:
            return SyncStatus.FAILED, f"Cherry-pick failed: {str(e)}", []
    
    def _get_current_branch(self) -> Optional[str]:
        result = self._run_git(['git', 'rev-parse', '--abbrev-ref', 'HEAD'])
        if result.returncode == 0:
            return result.stdout.strip()
        return None
    
    def _get_conflict_files(self) -> List[str]:
        result = self._run_git(['git', 'diff', '--name-only', '--diff-filter=U'])
        if result.returncode == 0:
            return [f.strip() for f in result.stdout.split('\n') if f.strip()]
        return []
    
    def abort_rebase(self) -> bool:
        result = self._run_git(['git', 'rebase', '--abort'])
        return result.returncode == 0
    
    def abort_merge(self) -> bool:
        result = self._run_git(['git', 'merge', '--abort'])
        return result.returncode == 0
    
    def continue_rebase(self) -> Tuple[SyncStatus, str, List[str]]:
        result = self._run_git(['git', 'rebase', '--continue'])
        if result.returncode != 0:
            conflicts = self._get_conflict_files()
            return SyncStatus.CONFLICT, result.stderr, conflicts
        return SyncStatus.SUCCESS, "Rebase continued successfully", []
    
    def continue_merge(self, commit_message: str = None) -> Tuple[SyncStatus, str, List[str]]:
        if commit_message:
            result = self._run_git(['git', 'commit', '-m', commit_message])
        result = self._run_git(['git', 'merge', '--continue', '--no-edit'])
        if result.returncode != 0:
            conflicts = self._get_conflict_files()
            return SyncStatus.CONFLICT, result.stderr, conflicts
        return SyncStatus.SUCCESS, "Merge continued successfully", []