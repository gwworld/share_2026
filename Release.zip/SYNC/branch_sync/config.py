import yaml
import json
from dataclasses import dataclass, field
from typing import List, Optional
from pathlib import Path


@dataclass
class RepoConfig:
    path: str = "."
    main_branch: str = "main"
    remote: str = "origin"


@dataclass
class BranchConfig:
    whitelist: List[str] = field(default_factory=list)
    blacklist: List[str] = field(default_factory=list)
    pattern: Optional[str] = None


@dataclass
class SyncConfig:
    strategy: str = "rebase"
    cherry_pick_commits: List[str] = field(default_factory=list)
    auto_push: bool = True
    force_push: bool = False


@dataclass
class ConflictRule:
    file_pattern: str
    prefer: str


@dataclass
class ConflictConfig:
    auto_resolve: bool = False
    resolution: str = "main"
    rules: List[ConflictRule] = field(default_factory=list)


@dataclass
class ParallelConfig:
    enabled: bool = True
    max_workers: int = 10
    timeout: int = 300


@dataclass
class LoggingConfig:
    level: str = "INFO"
    file: str = "sync.log"
    console: bool = True


@dataclass
class ReportConfig:
    format: str = "json"
    output: str = "sync_report.json"
    include_success: bool = True


@dataclass
class SafetyConfig:
    dry_run: bool = False
    backup_before_sync: bool = True
    rollback_on_failure: bool = True


@dataclass
class GitConfig:
    fetch_prune: bool = True
    rebase_autostash: bool = True
    commit_message: str = "Sync from main branch"


@dataclass
class Config:
    repo: RepoConfig = field(default_factory=RepoConfig)
    branches: BranchConfig = field(default_factory=BranchConfig)
    sync: SyncConfig = field(default_factory=SyncConfig)
    conflict: ConflictConfig = field(default_factory=ConflictConfig)
    parallel: ParallelConfig = field(default_factory=ParallelConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    report: ReportConfig = field(default_factory=ReportConfig)
    safety: SafetyConfig = field(default_factory=SafetyConfig)
    git: GitConfig = field(default_factory=GitConfig)


def load_config(config_path: str) -> Config:
    with open(config_path, 'r', encoding='utf-8') as f:
        if config_path.endswith('.json'):
            data = json.load(f)
        else:
            data = yaml.safe_load(f)
    return _parse_config(data)


def _parse_config(data: dict) -> Config:
    config = Config()
    
    if 'repo' in data:
        config.repo = RepoConfig(**data['repo'])
    
    if 'branches' in data:
        branch_data = data['branches'].copy()
        if 'rules' in branch_data:
            del branch_data['rules']
        config.branches = BranchConfig(**branch_data)
    
    if 'sync' in data:
        config.sync = SyncConfig(**data['sync'])
    
    if 'conflict' in data:
        conflict_data = data['conflict']
        rules = []
        if 'rules' in conflict_data:
            for rule in conflict_data['rules']:
                rules.append(ConflictRule(**rule))
        conflict_data['rules'] = rules
        config.conflict = ConflictConfig(**conflict_data)
    
    if 'parallel' in data:
        config.parallel = ParallelConfig(**data['parallel'])
    
    if 'logging' in data:
        config.logging = LoggingConfig(**data['logging'])
    
    if 'report' in data:
        config.report = ReportConfig(**data['report'])
    
    if 'safety' in data:
        config.safety = SafetyConfig(**data['safety'])
    
    if 'git' in data:
        config.git = GitConfig(**data['git'])
    
    return config


def save_config(config: Config, output_path: str):
    data = {
        'repo': config.repo.__dict__,
        'branches': config.branches.__dict__,
        'sync': config.sync.__dict__,
        'conflict': config.conflict.__dict__,
        'parallel': config.parallel.__dict__,
        'logging': config.logging.__dict__,
        'report': config.report.__dict__,
        'safety': config.safety.__dict__,
        'git': config.git.__dict__,
    }
    
    # Convert rules to dict
    data['conflict']['rules'] = [r.__dict__ for r in data['conflict']['rules']]
    
    with open(output_path, 'w', encoding='utf-8') as f:
        if output_path.endswith('.json'):
            json.dump(data, f, indent=2)
        else:
            yaml.dump(data, f, default_flow_style=False)


def create_default_config(path: str = "config.yaml"):
    config = Config()
    save_config(config, path)
    return config