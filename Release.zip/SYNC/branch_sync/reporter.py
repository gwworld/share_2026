import json
import logging
import sys
import time
from typing import List, Dict, Optional
from datetime import datetime
from pathlib import Path
from .config import Config
from .sync_strategy import SyncStatus
from .executor import SyncResult


class Logger:
    def __init__(self, config: Config):
        self.config = config
        self.logger = logging.getLogger('branch_sync')
        self._setup_logger()
    
    def _setup_logger(self):
        level = getattr(logging, self.config.logging.level.upper())
        self.logger.setLevel(level)
        
        if not self.logger.handlers:
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            
            if self.config.logging.console:
                console_handler = logging.StreamHandler(sys.stdout)
                console_handler.setLevel(level)
                console_handler.setFormatter(formatter)
                self.logger.addHandler(console_handler)
            
            if self.config.logging.file:
                file_handler = logging.FileHandler(
                    self.config.logging.file,
                    encoding='utf-8'
                )
                file_handler.setLevel(level)
                file_handler.setFormatter(formatter)
                self.logger.addHandler(file_handler)
    
    def debug(self, msg: str):
        self.logger.debug(msg)
    
    def info(self, msg: str):
        self.logger.info(msg)
    
    def warning(self, msg: str):
        self.logger.warning(msg)
    
    def error(self, msg: str):
        self.logger.error(msg)
    
    def success(self, msg: str):
        self.logger.info(f"✓ {msg}")
    
    def failed(self, msg: str):
        self.logger.error(f"✗ {msg}")
    
    def conflict(self, msg: str):
        self.logger.warning(f"⚠ {msg}")


class ReportGenerator:
    def __init__(self, config: Config):
        self.config = config
        self.report_config = config.report
    
    def generate(self, results: List[SyncResult], elapsed_time: float) -> Dict:
        success_count = sum(1 for r in results if r.status == SyncStatus.SUCCESS)
        conflict_count = sum(1 for r in results if r.status == SyncStatus.CONFLICT)
        failed_count = sum(1 for r in results if r.status == SyncStatus.FAILED)
        
        report = {
            'summary': {
                'total': len(results),
                'success': success_count,
                'conflict': conflict_count,
                'failed': failed_count,
                'elapsed_time': f"{elapsed_time:.2f}s",
                'timestamp': datetime.now().isoformat(),
                'main_branch': self.config.repo.main_branch,
                'strategy': self.config.sync.strategy,
                'dry_run': self.config.safety.dry_run
            },
            'branches': []
        }
        
        for result in results:
            if not self.report_config.include_success and result.status == SyncStatus.SUCCESS:
                continue
            
            branch_info = {
                'name': result.branch,
                'status': result.status.value,
                'message': result.message,
                'duration': f"{result.duration:.2f}s",
                'pushed': result.pushed,
            }
            
            if result.conflict_files:
                branch_info['conflict_files'] = result.conflict_files
            
            if result.error:
                branch_info['error'] = result.error
            
            report['branches'].append(branch_info)
        
        return report
    
    def save(self, report: Dict):
        output_path = self.report_config.output
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        
        if self.report_config.format == 'json':
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
        else:
            self._save_text_report(report, output_path)
        
        return output_path
    
    def _save_text_report(self, report: Dict, output_path: str):
        lines = []
        lines.append("=" * 60)
        lines.append("Git Branch Sync Report")
        lines.append("=" * 60)
        lines.append("")
        
        summary = report['summary']
        lines.append(f"Timestamp: {summary['timestamp']}")
        lines.append(f"Main Branch: {summary['main_branch']}")
        lines.append(f"Strategy: {summary['strategy']}")
        lines.append(f"Dry Run: {summary['dry_run']}")
        lines.append(f"Total Branches: {summary['total']}")
        lines.append(f"Success: {summary['success']}")
        lines.append(f"Conflicts: {summary['conflict']}")
        lines.append(f"Failed: {summary['failed']}")
        lines.append(f"Elapsed Time: {summary['elapsed_time']}")
        lines.append("")
        
        if report['branches']:
            lines.append("-" * 60)
            lines.append("Branch Details:")
            lines.append("-" * 60)
            
            for branch in report['branches']:
                lines.append(f"\n[{branch['status'].upper()}] {branch['name']}")
                lines.append(f"  Message: {branch['message']}")
                lines.append(f"  Duration: {branch['duration']}")
                lines.append(f"  Pushed: {branch['pushed']}")
                
                if branch.get('conflict_files'):
                    lines.append(f"  Conflict Files: {', '.join(branch['conflict_files'])}")
                
                if branch.get('error'):
                    lines.append(f"  Error: {branch['error']}")
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))


class ConsoleReporter:
    @staticmethod
    def print_summary(results: List[SyncResult], elapsed_time: float):
        success = sum(1 for r in results if r.status == SyncStatus.SUCCESS)
        conflicts = sum(1 for r in results if r.status == SyncStatus.CONFLICT)
        failed = sum(1 for r in results if r.status == SyncStatus.FAILED)
        
        print("\n" + "=" * 60)
        print("Git Branch Sync Summary")
        print("=" * 60)
        print(f"Total: {len(results)} | Success: {success} | Conflicts: {conflicts} | Failed: {failed}")
        print(f"Elapsed Time: {elapsed_time:.2f}s")
        print("=" * 60)
    
    @staticmethod
    def print_results(results: List[SyncResult]):
        print("\nBranch Details:")
        print("-" * 60)
        
        for result in results:
            status_icon = {
                SyncStatus.SUCCESS: "✓",
                SyncStatus.CONFLICT: "⚠",
                SyncStatus.FAILED: "✗",
                SyncStatus.SKIPPED: "○"
            }.get(result.status, "?")
            
            print(f"{status_icon} [{result.status.value.upper()}] {result.branch}")
            print(f"  {result.message}")
            print(f"  Duration: {result.duration:.2f}s")
            
            if result.conflict_files:
                print(f"  Conflicts: {', '.join(result.conflict_files)}")
            
            if result.error:
                print(f"  Error: {result.error}")
            
            print()
    
    @staticmethod
    def print_conflict_report(conflicts: Dict):
        if not conflicts.get('conflicts'):
            return
        
        print("\n" + "=" * 60)
        print("Conflict Report")
        print("=" * 60)
        print(f"Total Conflicts: {conflicts['total_conflicts']}")
        
        for conflict in conflicts['conflicts']:
            print(f"\nFile: {conflict['file']}")
        
        print("=" * 60)