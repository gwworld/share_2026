import subprocess
import logging
import shutil
import os
from datetime import datetime
from pathlib import Path
from typing import Optional
from .config import Config


logger = logging.getLogger(__name__)


class BackupManager:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = str(Path(config.repo.path).resolve())
        self.enabled = config.safety.backup_before_sync
    
    def create_backup(self, branch: str) -> Optional[str]:
        if not self.enabled:
            return None
        
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_branch = f"backup/{branch}_{timestamp}"
            
            result = subprocess.run(
                ['git', 'branch', backup_branch, branch],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            
            logger.info(f"Created backup branch: {backup_branch}")
            return backup_branch
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to create backup for {branch}: {e}")
            return None
    
    def restore_from_backup(self, branch: str, backup_branch: str) -> bool:
        try:
            subprocess.run(
                ['git', 'branch', '-f', branch, backup_branch],
                cwd=self.repo_path,
                capture_output=True,
                check=True
            )
            
            logger.info(f"Restored {branch} from {backup_branch}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to restore {branch} from {backup_branch}: {e}")
            return False
    
    def list_backups(self, branch: str = None) -> list:
        try:
            result = subprocess.run(
                ['git', 'branch', '--list', 'backup/*'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            
            backups = [b.strip() for b in result.stdout.split('\n') if b.strip()]
            
            if branch:
                backups = [b for b in backups if branch in b]
            
            return backups
            
        except subprocess.CalledProcessError:
            return []
    
    def cleanup_old_backups(self, days: int = 7):
        try:
            result = subprocess.run(
                ['git', 'branch', '--list', 'backup/*'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            
            backups = [b.strip() for b in result.stdout.split('\n') if b.strip()]
            
            for backup in backups:
                try:
                    subprocess.run(
                        ['git', 'branch', '-D', backup],
                        cwd=self.repo_path,
                        capture_output=True,
                        check=True
                    )
                    logger.info(f"Deleted old backup: {backup}")
                except subprocess.CalledProcessError:
                    pass
                    
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to cleanup backups: {e}")


class RollbackManager:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = config.repo.path
        self.enabled = config.safety.rollback_on_failure
    
    def can_rollback(self) -> bool:
        return self.enabled
    
    def rollback_branch(self, branch: str, backup_branch: str) -> bool:
        if not self.enabled:
            logger.warning("Rollback is disabled")
            return False
        
        try:
            subprocess.run(
                ['git', 'checkout', branch],
                cwd=self.repo_path,
                capture_output=True,
                check=True
            )
            
            subprocess.run(
                ['git', 'reset', '--hard', backup_branch],
                cwd=self.repo_path,
                capture_output=True,
                check=True
            )
            
            logger.info(f"Rolled back {branch} to {backup_branch}")
            return True
            
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to rollback {branch}: {e}")
            return False
    
    def abort_operations(self) -> bool:
        try:
            subprocess.run(
                ['git', 'rebase', '--abort'],
                cwd=self.repo_path,
                capture_output=True
            )
            
            subprocess.run(
                ['git', 'merge', '--abort'],
                cwd=self.repo_path,
                capture_output=True
            )
            
            logger.info("Aborted ongoing operations")
            return True
            
        except Exception as e:
            logger.error(f"Failed to abort operations: {e}")
            return False


class DryRunManager:
    def __init__(self, config: Config):
        self.config = config
        self.dry_run = config.safety.dry_run
    
    def is_dry_run(self) -> bool:
        return self.dry_run
    
    def simulate_sync(self, branch: str) -> dict:
        return {
            'branch': branch,
            'would_fetch': True,
            'would_rebase': self.config.sync.strategy == 'rebase',
            'would_merge': self.config.sync.strategy == 'merge',
            'would_cherry_pick': self.config.sync.strategy == 'cherry-pick',
            'would_push': self.config.sync.auto_push,
            'would_create_backup': self.config.safety.backup_before_sync
        }
    
    def check_prerequisites(self) -> dict:
        checks = {
            'git_available': self._check_git(),
            'repo_valid': self._check_repo(),
            'remote_exists': self._check_remote(),
            'main_branch_exists': self._check_main_branch()
        }
        
        return checks
    
    def _check_git(self) -> bool:
        try:
            result = subprocess.run(
                ['git', '--version'],
                capture_output=True,
                check=True
            )
            return result.returncode == 0
        except:
            return False
    
    def _check_repo(self) -> bool:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--is-inside-work-tree'],
                cwd=self.repo_path,
                capture_output=True,
                check=True
            )
            return result.returncode == 0
        except:
            return False
    
    def _check_remote(self) -> bool:
        try:
            result = subprocess.run(
                ['git', 'remote', '-v'],
                cwd=self.repo_path,
                capture_output=True,
                check=True
            )
            return self.config.repo.remote in result.stdout
        except:
            return False
    
    def _check_main_branch(self) -> bool:
        try:
            result = subprocess.run(
                ['git', 'show-ref', f'refs/heads/{self.config.repo.main_branch}'],
                cwd=self.repo_path,
                capture_output=True
            )
            return result.returncode == 0
        except:
            return False