import subprocess
import logging
import threading
import time
from pathlib import Path
from typing import List, Optional, Callable
from dataclasses import dataclass, field
from concurrent.futures import ThreadPoolExecutor, as_completed
from .config import Config
from .sync_strategy import SyncStatus
from .conflict_resolver import ConflictResolver


logger = logging.getLogger(__name__)


@dataclass
class SyncResult:
    branch: str
    status: SyncStatus
    message: str
    conflict_files: List[str] = field(default_factory=list)
    duration: float = 0.0
    pushed: bool = False
    error: Optional[str] = None


class BranchSyncWorker:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = str(Path(config.repo.path).resolve())
        self.main_branch = config.repo.main_branch
        self.remote = config.repo.remote
        self.dry_run = config.safety.dry_run
    
    def sync_branch(self, branch: str) -> SyncResult:
        start_time = time.time()
        
        try:
            if self.dry_run:
                return self._dry_run_sync(branch, start_time)
            
            return self._actual_sync(branch, start_time)
            
        except Exception as e:
            logger.error(f"Failed to sync branch {branch}: {e}")
            return SyncResult(
                branch=branch,
                status=SyncStatus.FAILED,
                message=str(e),
                duration=time.time() - start_time,
                error=str(e)
            )
    
    def _dry_run_sync(self, branch: str, start_time: float) -> SyncResult:
        logger.info(f"[DRY RUN] Would sync branch: {branch}")
        
        current = self._get_current_branch()
        
        if current != branch:
            logger.info(f"[DRY RUN] Would checkout to {branch}")
        
        logger.info(f"[DRY RUN] Would fetch {self.remote}/{self.main_branch}")
        
        return SyncResult(
            branch=branch,
            status=SyncStatus.SUCCESS,
            message="Dry run completed",
            duration=time.time() - start_time
        )
    
    def _actual_sync(self, branch: str, start_time: float) -> SyncResult:
        current = self._get_current_branch()
        
        if current != branch:
            self._run_git(['git', 'checkout', branch])
        
        upstream = self._get_main_branch_upstream()
        
        strategy = self.config.sync.strategy
        
        if strategy == "rebase":
            status, message, conflicts = self._rebase_branch(upstream)
        elif strategy == "merge":
            status, message, conflicts = self._merge_branch(upstream)
        elif strategy == "cherry-pick":
            status, message, conflicts = self._cherry_pick_branch()
        else:
            return SyncResult(
                branch=branch,
                status=SyncStatus.FAILED,
                message=f"Unknown strategy: {strategy}",
                duration=time.time() - start_time
            )
        
        if status == SyncStatus.CONFLICT:
            if self.config.conflict.auto_resolve:
                resolver = ConflictResolver(self.config)
                resolved = resolver.auto_resolve_conflicts(conflicts)
                logger.info(f"Auto-resolved conflicts: {resolved}")
                
                if self.config.sync.strategy == "rebase":
                    status, message, _ = self._continue_rebase()
                else:
                    status, message, _ = self._continue_merge()
        
        pushed = False
        if status == SyncStatus.SUCCESS and self.config.sync.auto_push:
            pushed = self._push_branch()
        
        return SyncResult(
            branch=branch,
            status=status,
            message=message,
            conflict_files=conflicts,
            duration=time.time() - start_time,
            pushed=pushed
        )
    
    def _rebase_branch(self, upstream: str):
        try:
            if self.config.git.rebase_autostash:
                result = self._run_git(['git', 'rebase', upstream, '--autostash'])
            else:
                result = self._run_git(['git', 'rebase', upstream])
            
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                return SyncStatus.CONFLICT, f"Rebase conflict: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, "Rebase completed", []
        except Exception as e:
            return SyncStatus.FAILED, str(e), []
    
    def _merge_branch(self, upstream: str):
        try:
            result = self._run_git(['git', 'merge', upstream, '--no-edit'])
            
            if result.returncode != 0:
                conflicts = self._get_conflict_files()
                return SyncStatus.CONFLICT, f"Merge conflict: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, "Merge completed", []
        except Exception as e:
            return SyncStatus.FAILED, str(e), []
    
    def _cherry_pick_branch(self):
        commits = self.config.sync.cherry_pick_commits
        if not commits:
            return SyncStatus.FAILED, "No commits specified", []
        
        try:
            for commit in commits:
                result = self._run_git(['git', 'cherry-pick', commit])
                
                if result.returncode != 0:
                    conflicts = self._get_conflict_files()
                    return SyncStatus.CONFLICT, f"Cherry-pick conflict: {result.stderr}", conflicts
            
            return SyncStatus.SUCCESS, f"Cherry-picked {len(commits)} commits", []
        except Exception as e:
            return SyncStatus.FAILED, str(e), []
    
    def _continue_rebase(self):
        result = self._run_git(['git', 'rebase', '--continue'])
        if result.returncode != 0:
            conflicts = self._get_conflict_files()
            return SyncStatus.CONFLICT, result.stderr, conflicts
        return SyncStatus.SUCCESS, "Rebase continued", []
    
    def _continue_merge(self):
        commit_msg = self.config.git.commit_message or "Merge from main branch"
        result = self._run_git(['git', 'commit', '-m', commit_msg])
        if result.returncode != 0:
            conflicts = self._get_conflict_files()
            return SyncStatus.CONFLICT, result.stderr, conflicts
        return SyncStatus.SUCCESS, "Merge continued", []
    
    def _push_branch(self) -> bool:
        try:
            if self.config.sync.force_push:
                result = self._run_git(['git', 'push', '-f', self.remote])
            else:
                result = self._run_git(['git', 'push', self.remote])
            
            return result.returncode == 0
        except Exception as e:
            logger.error(f"Failed to push: {e}")
            return False
    
    def _run_git(self, args: List[str]) -> subprocess.CompletedProcess:
        result = subprocess.run(
            args,
            cwd=self.repo_path,
            capture_output=True,
            text=True
        )
        return result
    
    def _get_current_branch(self) -> Optional[str]:
        result = self._run_git(['git', 'rev-parse', '--abbrev-ref', 'HEAD'])
        if result.returncode == 0:
            return result.stdout.strip()
        return None
    
    def _get_conflict_files(self) -> List[str]:
        result = self._run_git(['git', 'diff', '--name-only', '--diff-filter=U'])
        if result.returncode == 0:
            return [f.strip() for f in result.stdout.split('\n') if f.strip()]
        return []
    
    def _get_main_branch_upstream(self) -> str:
        result = self._run_git(['git', 'rev-parse', self.main_branch])
        if result.returncode == 0:
            return result.stdout.strip()
        return self.main_branch


class ParallelExecutor:
    def __init__(self, config: Config):
        self.config = config
        self.max_workers = config.parallel.max_workers
        self.timeout = config.parallel.timeout
        self.enabled = config.parallel.enabled
    
    def execute(self, branches: List[str], worker_func: callable) -> List[SyncResult]:
        if not self.enabled or len(branches) == 1:
            return self._execute_sequential(branches, worker_func)
        
        return self._execute_parallel(branches, worker_func)
    
    def _execute_sequential(self, branches: List[str], worker_func: callable) -> List[SyncResult]:
        results = []
        for branch in branches:
            result = worker_func(branch)
            results.append(result)
        return results
    
    def _execute_parallel(self, branches: List[str], worker_func: callable) -> List[SyncResult]:
        results = []
        lock = threading.Lock()
        
        def worker_wrapper(branch):
            result = worker_func(branch)
            with lock:
                results.append(result)
            return result
        
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {executor.submit(worker_wrapper, branch): branch for branch in branches}
            
            for future in as_completed(futures):
                branch = futures[future]
                try:
                    future.result(timeout=self.timeout)
                except Exception as e:
                    logger.error(f"Branch {branch} failed: {e}")
                    results.append(SyncResult(
                        branch=branch,
                        status=SyncStatus.FAILED,
                        message=str(e),
                        error=str(e)
                    ))
        
        return results