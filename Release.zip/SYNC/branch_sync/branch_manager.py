import re
import subprocess
import logging
import os
from typing import List, Optional
from pathlib import Path
from .config import Config


logger = logging.getLogger(__name__)


class BranchManager:
    def __init__(self, config: Config):
        self.config = config
        self.repo_path = str(Path(config.repo.path).resolve())
        self.main_branch = config.repo.main_branch
        self.remote = config.repo.remote
        self.whitelist = config.branches.whitelist
        self.blacklist = config.branches.blacklist
        self.pattern = config.branches.pattern
    
    def get_local_branches(self) -> List[str]:
        try:
            result = subprocess.run(
                ['git', 'branch', '--format=%(refname:short)'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            branches = [b.strip() for b in result.stdout.split('\n') if b.strip()]
            logger.info(f"Found {len(branches)} local branches")
            return branches
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get local branches: {e}")
            return []
    
    def get_remote_branches(self) -> List[str]:
        try:
            result = subprocess.run(
                ['git', 'branch', '-r', '--format=%(refname:short)'],
                cwd=self.repo_path,
                capture_output=True,
                text=True,
                check=True
            )
            branches = []
            for b in result.stdout.split('\n'):
                b = b.strip()
                if b and not b.startswith(f'{self.remote}/HEAD'):
                    branches.append(b.replace(f'{self.remote}/', ''))
            logger.info(f"Found {len(branches)} remote branches")
            return branches
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to get remote branches: {e}")
            return []
    
    def get_all_branches(self) -> List[str]:
        local = self.get_local_branches()
        remote = self.get_remote_branches()
        all_branches = list(set(local + remote))
        return all_branches
    
    def filter_branches(self, branches: List[str]) -> List[str]:
        filtered = []
        
        for branch in branches:
            if branch == self.main_branch:
                continue
            
            if branch in self.blacklist:
                logger.debug(f"Branch {branch} excluded by blacklist")
                continue
            
            if self.whitelist and branch not in self.whitelist:
                logger.debug(f"Branch {branch} not in whitelist")
                continue
            
            if self.pattern:
                try:
                    if not re.match(self.pattern, branch):
                        logger.debug(f"Branch {branch} does not match pattern {self.pattern}")
                        continue
                except re.error as e:
                    logger.warning(f"Invalid regex pattern: {e}")
            
            filtered.append(branch)
        
        logger.info(f"Filtered {len(filtered)} branches from {len(branches)} total")
        return filtered
    
    def get_target_branches(self) -> List[str]:
        all_branches = self.get_all_branches()
        return self.filter_branches(all_branches)
    
    def branch_exists(self, branch: str) -> bool:
        local = self.get_local_branches()
        return branch in local
    
    def get_branch_tracking_info(self, branch: str) -> Optional[dict]:
        try:
            result = subprocess.run(
                ['git', 'rev-parse', '--abbrev-ref', f'{branch}@{upstream}'],
                cwd=self.repo_path,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                tracking = result.stdout.strip()
                return {'tracking': tracking}
        except subprocess.CalledProcessError:
            pass
        return None