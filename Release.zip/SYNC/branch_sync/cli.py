import argparse
import sys
import os
import time
import json
from pathlib import Path

from .config import load_config, create_default_config
from .branch_manager import BranchManager
from .executor import BranchSyncWorker, ParallelExecutor
from .reporter import Logger, ReportGenerator, ConsoleReporter
from .safety import BackupManager, RollbackManager, DryRunManager


class BranchSyncCLI:
    def __init__(self):
        self.config = None
        self.logger = None
        self.branch_manager = None
        self.executor = None
        self.backup_manager = None
        self.rollback_manager = None
        self.dry_run_manager = None
        self.report_generator = None
    
    def run(self, args=None):
        parser = self._create_parser()
        parsed_args = parser.parse_args(args)
        
        if parsed_args.version:
            self._print_version()
            return 0
        
        if parsed_args.init:
            return self._init_config(parsed_args)
        
        if not parsed_args.config:
            parsed_args.config = 'config.yaml'
        
        if not os.path.exists(parsed_args.config):
            print(f"Error: Config file not found: {parsed_args.config}")
            print("Use --init to create a default config file")
            return 1
        
        try:
            self.config = load_config(parsed_args.config)
        except Exception as e:
            print(f"Error: Failed to load config: {e}")
            return 1
        
        if parsed_args.dry_run:
            self.config.safety.dry_run = True
        
        if parsed_args.strategy:
            self.config.sync.strategy = parsed_args.strategy
        
        if parsed_args.workers:
            self.config.parallel.max_workers = parsed_args.workers
        
        self._initialize_components()
        
        if parsed_args.list:
            return self._list_branches()
        
        if parsed_args.check:
            return self._check_prerequisites()
        
        return self._sync_branches()
    
    def _create_parser(self):
        parser = argparse.ArgumentParser(
            prog='branch-sync',
            description='Git Branch Sync Automation Tool',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  branch-sync --init                          Create default config
  branch-sync --config myconfig.yaml          Use custom config
  branch-sync --dry-run                       Check without executing
  branch-sync --list                          List target branches
  branch-sync --check                         Check prerequisites
  branch-sync --strategy merge                Use merge instead of rebase
  branch-sync --workers 5                    Limit to 5 parallel workers
            """
        )
        
        parser.add_argument('--version', action='store_true', help='Show version')
        parser.add_argument('--config', '-c', type=str, help='Config file path')
        parser.add_argument('--init', action='store_true', help='Create default config file')
        parser.add_argument('--dry-run', action='store_true', help='Dry run mode')
        parser.add_argument('--list', action='store_true', help='List target branches')
        parser.add_argument('--check', action='store_true', help='Check prerequisites')
        parser.add_argument('--strategy', choices=['rebase', 'merge', 'cherry-pick'], help='Sync strategy')
        parser.add_argument('--workers', type=int, help='Max parallel workers')
        
        return parser
    
    def _initialize_components(self):
        self.logger = Logger(self.config)
        self.branch_manager = BranchManager(self.config)
        self.executor = ParallelExecutor(self.config)
        self.backup_manager = BackupManager(self.config)
        self.rollback_manager = RollbackManager(self.config)
        self.dry_run_manager = DryRunManager(self.config)
        self.report_generator = ReportGenerator(self.config)
    
    def _init_config(self, args):
        config_path = args.config or 'config.yaml'
        
        if os.path.exists(config_path):
            response = input(f"{config_path} already exists. Overwrite? (y/n): ")
            if response.lower() != 'y':
                return 0
        
        create_default_config(config_path)
        print(f"Created default config: {config_path}")
        print("Please edit the config file to match your repository settings")
        return 0
    
    def _print_version(self):
        print("Git Branch Sync Automation Tool v1.0.0")
    
    def _list_branches(self):
        branches = self.branch_manager.get_target_branches()
        
        print(f"\nMain Branch: {self.config.repo.main_branch}")
        print(f"Target Branches ({len(branches)}):")
        print("-" * 40)
        
        for branch in branches:
            print(f"  - {branch}")
        
        return 0
    
    def _check_prerequisites(self):
        checks = self.dry_run_manager.check_prerequisites()
        
        print("\nPrerequisites Check:")
        print("-" * 40)
        
        for check, result in checks.items():
            status = "✓" if result else "✗"
            print(f"  {status} {check}")
        
        all_passed = all(checks.values())
        
        print("-" * 40)
        if all_passed:
            print("All checks passed!")
            return 0
        else:
            print("Some checks failed!")
            return 1
    
    def _sync_branches(self):
        start_time = time.time()
        
        if self.config.safety.dry_run:
            self.logger.info("=== DRY RUN MODE ===")
            self.logger.info("No actual changes will be made")
        
        branches = self.branch_manager.get_target_branches()
        
        if not branches:
            self.logger.warning("No branches to sync")
            return 0
        
        self.logger.info(f"Found {len(branches)} branches to sync")
        
        worker = BranchSyncWorker(self.config)
        
        results = self.executor.execute(branches, worker.sync_branch)
        
        elapsed_time = time.time() - start_time
        
        ConsoleReporter.print_summary(results, elapsed_time)
        ConsoleReporter.print_results(results)
        
        report = self.report_generator.generate(results, elapsed_time)
        report_path = self.report_generator.save(report)
        self.logger.info(f"Report saved to: {report_path}")
        
        return 0


def main():
    cli = BranchSyncCLI()
    sys.exit(cli.run())


if __name__ == '__main__':
    main()