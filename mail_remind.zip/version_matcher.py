import re
import os
from typing import Tuple, Dict, Any, List
from git_checker import GitChecker


class VersionMatcher:
    VERSION_PATTERNS = [
        r'v(\d+\.\d+\.\d+)',
        r'v(\d+\.\d+)',
        r'(\d+\.\d+\.\d+)',
        r'(\d+\.\d+)',
        r'rev_(\d+)',
        r'r(\d+)',
    ]
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.git_checker = GitChecker(self.config)
    
    def extract_version_from_filename(self, filename: str) -> str:
        for pattern in self.VERSION_PATTERNS:
            match = re.search(pattern, filename, re.IGNORECASE)
            if match:
                return match.group(0)
        return ""
    
    def extract_version_from_string(self, text: str) -> str:
        for pattern in self.VERSION_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(0)
        return ""
    
    def parse_version(self, version: str) -> Tuple[int, ...]:
        version = version.replace('v', '').replace('V', '')
        parts = version.split('.')
        try:
            return tuple(int(p) for p in parts)
        except ValueError:
            return (0,)
    
    def compare_versions(self, version1: str, version2: str) -> int:
        v1 = self.parse_version(version1)
        v2 = self.parse_version(version2)
        
        if v1 > v2:
            return 1
        elif v1 < v2:
            return -1
        return 0
    
    def check_version(self, repo_url: str, file_path: str, expected_version: str) -> Tuple[bool, str]:
        try:
            info = self.git_checker.get_file_info(repo_url, file_path)
            
            if "error" in info:
                return False, f"Failed to get file info: {info['error']}"
            
            if not info.get("commit_hash"):
                return False, "No commit information found for file"
            
            commit_msg = info.get("message", "")
            extracted = self.extract_version_from_string(commit_msg)
            
            if extracted:
                if self.compare_versions(extracted, expected_version) == 0:
                    return True, f"Version match: {extracted} == {expected_version}"
                else:
                    return False, f"Version mismatch: found {extracted}, expected {expected_version}"
            
            filename_version = self.extract_version_from_filename(os.path.basename(file_path))
            if filename_version:
                if self.compare_versions(filename_version, expected_version) == 0:
                    return True, f"Version in filename matches: {filename_version}"
                else:
                    return False, f"Version mismatch: filename has {filename_version}, expected {expected_version}"
            
            return True, "Version check completed (no explicit version found in commit)"
            
        except Exception as e:
            return False, f"Error checking version: {str(e)}"
    
    def validate_version_format(self, version: str) -> Tuple[bool, str]:
        for pattern in self.VERSION_PATTERNS:
            if re.match(pattern, version, re.IGNORECASE):
                return True, "Valid version format"
        
        return False, f"Invalid version format: {version}. Expected patterns: {self.VERSION_PATTERNS}"
    
    def get_version_from_tag(self, repo_url: str, file_path: str) -> List[str]:
        tags = []
        
        try:
            import subprocess
            result = subprocess.run(
                ["git", "ls-remote", "--tags", repo_url],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if file_path.split('/')[-1].replace('.rule', '') in line:
                        version = self.extract_version_from_string(line)
                        if version:
                            tags.append(version)
                            
        except Exception:
            pass
        
        return tags
