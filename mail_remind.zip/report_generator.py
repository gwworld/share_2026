import json
import os
from datetime import datetime
from typing import Dict, List, Any
from typing import Dict, List, Any


class ReportGenerator:
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.report_format = self.config.get("report_format", "json")
        self.output_dir = self.config.get("output_dir", "./reports")
    
    def generate(self, qc_results: List[Dict[str, Any]], release_id: str) -> Dict[str, Any]:
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        
        total_items = len(qc_results)
        passed_items = sum(1 for r in qc_results if r.get("overall_status") == "PASS")
        failed_items = total_items - passed_items
        
        report = {
            "release_id": release_id,
            "timestamp": timestamp,
            "summary": {
                "total_items": total_items,
                "passed": passed_items,
                "failed": failed_items,
                "pass_rate": f"{(passed_items/total_items*100):.2f}%" if total_items > 0 else "0%"
            },
            "results": qc_results,
            "status": "PASS" if failed_items == 0 else "FAIL"
        }
        
        self._save_report(report)
        
        return report
    
    def _save_report(self, report: Dict[str, Any]):
        if not os.path.exists(self.output_dir):
            os.makedirs(self.output_dir)
        
        release_id = report.get("release_id", "unknown")
        filename = f"qc_report_{release_id}.{self.report_format}"
        filepath = os.path.join(self.output_dir, filename)
        
        if self.report_format == "json":
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
        elif self.report_format == "txt":
            self._save_text_report(report, filepath)
        elif self.report_format == "html":
            self._save_html_report(report, filepath)
        
        print(f"[Report] Saved to: {filepath}")
    
    def _save_text_report(self, report: Dict[str, Any], filepath: str):
        lines = [
            f"Release QC Report - {report.get('release_id')}",
            f"Generated: {report.get('timestamp')}",
            "=" * 50,
            f"Total Items: {report['summary']['total_items']}",
            f"Passed: {report['summary']['passed']}",
            f"Failed: {report['summary']['failed']}",
            f"Pass Rate: {report['summary']['pass_rate']}",
            "=" * 50,
            ""
        ]
        
        for result in report.get("results", []):
            status = result.get("overall_status", "UNKNOWN")
            file_id = result.get("file_id", "N/A")
            version = result.get("version", "N/A")
            
            lines.append(f"[{status}] {file_id} ({version})")
            
            for check_name, check_result in result.get("checks", {}).items():
                lines.append(f"  - {check_name}: {check_result['status']} - {check_result['message']}")
            
            lines.append("")
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write('\n'.join(lines))
    
    def _save_html_report(self, report: Dict[str, Any], filepath: str):
        html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Release QC Report - {report.get('release_id')}</title>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        h1 {{ color: #333; }}
        .summary {{ background: #f5f5f5; padding: 15px; border-radius: 5px; margin-bottom: 20px; }}
        .pass {{ color: green; }}
        .fail {{ color: red; font-weight: bold; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #4CAF50; color: white; }}
    </style>
</head>
<body>
    <h1>Release QC Report</h1>
    <div class="summary">
        <p><strong>Release ID:</strong> {report.get('release_id')}</p>
        <p><strong>Timestamp:</strong> {report.get('timestamp')}</p>
        <p><strong>Total Items:</strong> {report['summary']['total_items']}</p>
        <p><strong>Passed:</strong> <span class="pass">{report['summary']['passed']}</span></p>
        <p><strong>Failed:</strong> <span class="fail">{report['summary']['failed']}</span></p>
        <p><strong>Pass Rate:</strong> {report['summary']['pass_rate']}</p>
    </div>
    
    <h2>Results</h2>
    <table>
        <tr>
            <th>File ID</th>
            <th>Version</th>
            <th>Status</th>
            <th>Details</th>
        </tr>
"""
        
        for result in report.get("results", []):
            status = result.get("overall_status", "UNKNOWN")
            file_id = result.get("file_id", "N/A")
            version = result.get("version", "N/A")
            
            details = "<br>".join([
                f"{k}: {v['status']} - {v['message']}"
                for k, v in result.get("checks", {}).items()
            ])
            
            status_class = "pass" if status == "PASS" else "fail"
            
            html += f"""
        <tr>
            <td>{file_id}</td>
            <td>{version}</td>
            <td class="{status_class}">{status}</td>
            <td>{details}</td>
        </tr>
"""
        
        html += """
    </table>
</body>
</html>
"""
        
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(html)
    
    def generate_summary(self, reports: List[Dict[str, Any]]) -> Dict[str, Any]:
        total = sum(r['summary']['total_items'] for r in reports)
        passed = sum(r['summary']['passed'] for r in reports)
        failed = sum(r['summary']['failed'] for r in reports)
        
        return {
            "total_reports": len(reports),
            "total_items": total,
            "total_passed": passed,
            "total_failed": failed,
            "overall_pass_rate": f"{(passed/total*100):.2f}%" if total > 0 else "0%"
        }
