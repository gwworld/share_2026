import unittest
import os
import sys
import tempfile
import shutil
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from git_checker import GitChecker


class TestGitChecker(unittest.TestCase):
    def setUp(self):
        self.config = {
            "timeout": 5,
            "retry_times": 1,
            "clone_depth": 1
        }
        self.checker = GitChecker(self.config)
        
    def tearDown(self):
        self.checker.cleanup()
        
    @patch('subprocess.run')
    def test_check_file_exists_success(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="rules/drc_001.rule\nrules/drc_002.rule",
            stderr=""
        )
        
        with patch.object(self.checker, '_clone_repo', return_value="/tmp/fake_repo"):
            result, msg = self.checker.check_file_exists(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule"
            )
            
            self.assertTrue(result)
            self.assertIn("exists", msg.lower())
            
    @patch('subprocess.run')
    def test_check_file_exists_not_found(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="rules/drc_002.rule",
            stderr=""
        )
        
        with patch.object(self.checker, '_clone_repo', return_value="/tmp/fake_repo"):
            result, msg = self.checker.check_file_exists(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule"
            )
            
            self.assertFalse(result)
            self.assertIn("not found", msg.lower())
            
    @patch('subprocess.run')
    def test_check_file_pushed_success(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="abc1234567890def",
            stderr=""
        )
        
        with patch.object(self.checker, '_clone_repo', return_value="/tmp/fake_repo"):
            result, msg = self.checker.check_file_pushed(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule"
            )
            
            self.assertTrue(result)
            self.assertIn("pushed", msg.lower())
            
    @patch('subprocess.run')
    def test_check_file_latest_success(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Update drc_001 to v1.2.0",
            stderr=""
        )
        
        with patch.object(self.checker, '_clone_repo', return_value="/tmp/fake_repo"):
            result, msg = self.checker.check_file_latest(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule",
                "v1.2.0"
            )
            
            self.assertTrue(result)
            
    @patch('subprocess.run')
    def test_check_file_latest_version_mismatch(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="Update drc_001 to v1.0.0",
            stderr=""
        )
        
        with patch.object(self.checker, '_clone_repo', return_value="/tmp/fake_repo"):
            result, msg = self.checker.check_file_latest(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule",
                "v1.2.0"
            )
            
            self.assertTrue(result)
            
    def test_run_command_timeout(self):
        with patch('subprocess.run', side_effect=lambda *args, **kwargs: (_ for _ in ()).throw(Exception("timeout"))):
            success, stdout, stderr = self.checker._run_command(["sleep", "10"])
            
            self.assertFalse(success)
            
    def test_clone_repo_exception(self):
        with patch('subprocess.run', return_value=MagicMock(returncode=1, stdout="", stderr="Error")):
            with self.assertRaises(RuntimeError):
                self.checker._clone_repo("https://github.com/invalid/repo.git")


class TestGitCheckerIntegration(unittest.TestCase):
    def setUp(self):
        self.checker = GitChecker({"timeout": 5, "clone_depth": 1})
        
    def tearDown(self):
        self.checker.cleanup()
        
    def test_checker_initialization(self):
        self.assertEqual(self.checker.timeout, 5)
        self.assertEqual(self.checker.clone_depth, 1)


if __name__ == "__main__":
    unittest.main()
