import unittest
import os
import sys
from unittest.mock import patch, MagicMock, call

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from email_notifier import EmailNotifier


class TestEmailNotifier(unittest.TestCase):
    def setUp(self):
        self.smtp_config = {
            "host": "smtp.test.com",
            "port": 587,
            "username": "test@test.com",
            "password": "test_password",
            "use_tls": True
        }
        self.email_config = {
            "from": "qc@test.com",
            "to": ["tester@test.com", "manager@test.com"],
            "subject": "QC Report - {release_id}"
        }
        self.notifier = EmailNotifier(self.smtp_config, self.email_config)
        
    def test_initialization(self):
        self.assertEqual(self.notifier.smtp_config["host"], "smtp.test.com")
        self.assertEqual(self.notifier.email_config["from"], "qc@test.com")
        
    def test_format_report_text(self):
        report = {
            "release_id": "TEST_001",
            "timestamp": "2026-04-12 10:00:00",
            "status": "PASS",
            "summary": {
                "total_items": 3,
                "passed": 3,
                "failed": 0,
                "pass_rate": "100.00%"
            },
            "results": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.2.0",
                    "overall_status": "PASS",
                    "checks": {
                        "file_exists": {"status": "PASS", "message": "OK"}
                    }
                }
            ]
        }
        
        text = self.notifier._format_report_text(report)
        
        self.assertIn("TEST_001", text)
        self.assertIn("DRC_001", text)
        self.assertIn("100.00%", text)
        
    def test_format_report_html(self):
        report = {
            "release_id": "TEST_001",
            "timestamp": "2026-04-12 10:00:00",
            "status": "FAIL",
            "summary": {
                "total_items": 3,
                "passed": 2,
                "failed": 1,
                "pass_rate": "66.67%"
            },
            "results": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.2.0",
                    "overall_status": "FAIL",
                    "checks": {
                        "file_exists": {"status": "FAIL", "message": "File not found"}
                    }
                }
            ]
        }
        
        html = self.notifier._format_report_html(report)
        
        self.assertIn("TEST_001", html)
        self.assertIn("DRC_001", html)
        self.assertIn("FAIL", html)
        
    @patch('smtplib.SMTP')
    def test_send_report_success(self, mock_smtp):
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        report = {
            "release_id": "TEST_001",
            "timestamp": "2026-04-12 10:00:00",
            "status": "PASS",
            "summary": {
                "total_items": 1,
                "passed": 1,
                "failed": 0,
                "pass_rate": "100.00%"
            },
            "results": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.2.0",
                    "overall_status": "PASS",
                    "checks": {}
                }
            ]
        }
        
        self.notifier.send_report(report, "TEST_001")
        
        mock_server.send_message.assert_called_once()
        
    @patch('smtplib.SMTP')
    def test_send_report_failure(self, mock_smtp):
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        report = {
            "release_id": "TEST_002",
            "timestamp": "2026-04-12 10:00:00",
            "status": "FAIL",
            "summary": {
                "total_items": 1,
                "passed": 0,
                "failed": 1,
                "pass_rate": "0.00%"
            },
            "results": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.2.0",
                    "overall_status": "FAIL",
                    "checks": {}
                }
            ]
        }
        
        self.notifier.send_report(report, "TEST_002")
        
        mock_server.send_message.assert_called_once()
        
        args = mock_server.send_message.call_args[0][0]
        self.assertIn("FAIL", args["Subject"])
        
    def test_send_report_no_smtp_config(self):
        notifier = EmailNotifier({}, {})
        
        report = {
            "release_id": "TEST_001",
            "status": "PASS",
            "summary": {"total_items": 1, "passed": 1, "failed": 0, "pass_rate": "100%"},
            "results": []
        }
        
        notifier.send_report(report, "TEST_001")
        
    def test_send_report_no_recipients(self):
        notifier = EmailNotifier(self.smtp_config, {"to": []})
        
        report = {
            "release_id": "TEST_001",
            "status": "PASS",
            "summary": {"total_items": 1, "passed": 1, "failed": 0, "pass_rate": "100%"},
            "results": []
        }
        
        notifier.send_report(report, "TEST_001")


class TestEmailNotifierAlert(unittest.TestCase):
    def setUp(self):
        self.smtp_config = {
            "host": "smtp.test.com",
            "port": 587,
            "username": "test@test.com",
            "password": "test_password",
            "use_tls": True
        }
        self.email_config = {
            "from": "qc@test.com",
            "to": ["tester@test.com"]
        }
        self.notifier = EmailNotifier(self.smtp_config, self.email_config)
        
    @patch('smtplib.SMTP')
    def test_send_alert(self, mock_smtp):
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server
        
        self.notifier.send_alert("Test Alert", "This is a test alert")
        
        mock_server.send_message.assert_called_once()


if __name__ == "__main__":
    unittest.main()
