import unittest
import os
import sys
import json
import tempfile
import shutil

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from report_generator import ReportGenerator


class TestReportGenerator(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config = {
            "report_format": "json",
            "output_dir": self.temp_dir
        }
        self.generator = ReportGenerator(self.config)
        
    def tearDown(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            
    def test_generate_report_all_pass(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "git_repo": "https://github.com/test/repo.git",
                "file_path": "rules/drc_001.rule",
                "checks": {
                    "file_exists": {"status": "PASS", "message": "File exists"},
                    "version_match": {"status": "PASS", "message": "Version matches"},
                    "pushed_to_remote": {"status": "PASS", "message": "Pushed"},
                    "is_latest": {"status": "PASS", "message": "Is latest"}
                },
                "overall_status": "PASS"
            },
            {
                "file_id": "DRC_002",
                "version": "v2.1.0",
                "git_repo": "https://github.com/test/repo.git",
                "file_path": "rules/drc_002.rule",
                "checks": {
                    "file_exists": {"status": "PASS", "message": "File exists"},
                    "version_match": {"status": "PASS", "message": "Version matches"},
                    "pushed_to_remote": {"status": "PASS", "message": "Pushed"},
                    "is_latest": {"status": "PASS", "message": "Is latest"}
                },
                "overall_status": "PASS"
            }
        ]
        
        report = self.generator.generate(qc_results, "TEST_001")
        
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["summary"]["total_items"], 2)
        self.assertEqual(report["summary"]["passed"], 2)
        self.assertEqual(report["summary"]["failed"], 0)
        
    def test_generate_report_with_failures(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "git_repo": "https://github.com/test/repo.git",
                "file_path": "rules/drc_001.rule",
                "checks": {
                    "file_exists": {"status": "PASS", "message": "File exists"},
                    "version_match": {"status": "FAIL", "message": "Version mismatch"}
                },
                "overall_status": "FAIL"
            }
        ]
        
        report = self.generator.generate(qc_results, "TEST_002")
        
        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["summary"]["failed"], 1)
        
    def test_generate_report_saves_file(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "git_repo": "https://github.com/test/repo.git",
                "file_path": "rules/drc_001.rule",
                "checks": {},
                "overall_status": "PASS"
            }
        ]
        
        report = self.generator.generate(qc_results, "TEST_003")
        
        expected_file = os.path.join(self.temp_dir, "qc_report_TEST_003.json")
        self.assertTrue(os.path.exists(expected_file))
        
    def test_pass_rate_calculation(self):
        qc_results = [
            {"overall_status": "PASS"},
            {"overall_status": "PASS"},
            {"overall_status": "FAIL"},
            {"overall_status": "PASS"}
        ]
        
        report = self.generator.generate(qc_results, "TEST_004")
        
        self.assertEqual(report["summary"]["pass_rate"], "75.00%")


class TestReportGeneratorTextFormat(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config = {
            "report_format": "txt",
            "output_dir": self.temp_dir
        }
        self.generator = ReportGenerator(self.config)
        
    def tearDown(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            
    def test_generate_text_report(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "checks": {
                    "file_exists": {"status": "PASS", "message": "OK"}
                },
                "overall_status": "PASS"
            }
        ]
        
        report = self.generator.generate(qc_results, "TEST_TXT")
        
        expected_file = os.path.join(self.temp_dir, "qc_report_TEST_TXT.txt")
        self.assertTrue(os.path.exists(expected_file))
        
        with open(expected_file, 'r') as f:
            content = f.read()
            self.assertIn("DRC_001", content)


class TestReportGeneratorHTMLFormat(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.config = {
            "report_format": "html",
            "output_dir": self.temp_dir
        }
        self.generator = ReportGenerator(self.config)
        
    def tearDown(self):
        if os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            
    def test_generate_html_report(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "checks": {
                    "file_exists": {"status": "PASS", "message": "OK"}
                },
                "overall_status": "PASS"
            }
        ]
        
        report = self.generator.generate(qc_results, "TEST_HTML")
        
        expected_file = os.path.join(self.temp_dir, "qc_report_TEST_HTML.html")
        self.assertTrue(os.path.exists(expected_file))
        
        with open(expected_file, 'r') as f:
            content = f.read()
            self.assertIn("<html>", content.lower())
            self.assertIn("DRC_001", content)


class TestReportGeneratorSummary(unittest.TestCase):
    def setUp(self):
        self.generator = ReportGenerator()
        
    def test_generate_summary(self):
        reports = [
            {
                "summary": {"total_items": 10, "passed": 8, "failed": 2}
            },
            {
                "summary": {"total_items": 5, "passed": 5, "failed": 0}
            }
        ]
        
        summary = self.generator.generate_summary(reports)
        
        self.assertEqual(summary["total_reports"], 2)
        self.assertEqual(summary["total_items"], 15)
        self.assertEqual(summary["total_passed"], 13)
        self.assertEqual(summary["total_failed"], 2)


if __name__ == "__main__":
    unittest.main()
