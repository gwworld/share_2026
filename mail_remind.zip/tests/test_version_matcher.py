import unittest
import os
import sys
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from version_matcher import VersionMatcher


class TestVersionMatcher(unittest.TestCase):
    def setUp(self):
        self.matcher = VersionMatcher()
        
    def test_extract_version_from_filename_v1(self):
        result = self.matcher.extract_version_from_filename("drc_001_v1.2.0.rule")
        self.assertEqual(result, "v1.2.0")
        
    def test_extract_version_from_filename_v2(self):
        result = self.matcher.extract_version_from_filename("drc_002_v2.1.rule")
        self.assertEqual(result, "v2.1")
        
    def test_extract_version_from_filename_no_version(self):
        result = self.matcher.extract_version_from_filename("drc_003.rule")
        self.assertEqual(result, "")
        
    def test_extract_version_from_filename_rev(self):
        result = self.matcher.extract_version_from_filename("drc_004_rev_123.rule")
        self.assertEqual(result, "rev_123")
        
    def test_extract_version_from_string(self):
        result = self.matcher.extract_version_from_string("Update DRC to v1.2.0 for release")
        self.assertEqual(result, "v1.2.0")
        
    def test_extract_version_from_string_multiple(self):
        result = self.matcher.extract_version_from_string("v1.0.0 and v2.0.0")
        self.assertEqual(result, "v1.0.0")
        
    def test_parse_version_semver(self):
        result = self.matcher.parse_version("v1.2.3")
        self.assertEqual(result, (1, 2, 3))
        
    def test_parse_version_minor(self):
        result = self.matcher.parse_version("v2.1")
        self.assertEqual(result, (2, 1))
        
    def test_parse_version_invalid(self):
        result = self.matcher.parse_version("invalid")
        self.assertEqual(result, (0,))
        
    def test_compare_versions_equal(self):
        result = self.matcher.compare_versions("v1.2.0", "v1.2.0")
        self.assertEqual(result, 0)
        
    def test_compare_versions_greater(self):
        result = self.matcher.compare_versions("v2.0.0", "v1.0.0")
        self.assertEqual(result, 1)
        
    def test_compare_versions_less(self):
        result = self.matcher.compare_versions("v1.0.0", "v2.0.0")
        self.assertEqual(result, -1)
        
    def test_compare_versions_different_formats(self):
        result = self.matcher.compare_versions("1.2.0", "v1.2.0")
        self.assertEqual(result, 0)
        
    def test_validate_version_format_valid(self):
        result, msg = self.matcher.validate_version_format("v1.2.0")
        self.assertTrue(result)
        
    def test_validate_version_format_valid2(self):
        result, msg = self.matcher.validate_version_format("2.1")
        self.assertTrue(result)
        
    def test_validate_version_format_valid3(self):
        result, msg = self.matcher.validate_version_format("rev_123")
        self.assertTrue(result)
        
    def test_validate_version_format_invalid(self):
        result, msg = self.matcher.validate_version_format("invalid_version")
        self.assertFalse(result)


class TestVersionMatcherWithMock(unittest.TestCase):
    def setUp(self):
        self.matcher = VersionMatcher()
        
    @patch('version_matcher.GitChecker')
    def test_check_version_success(self, MockGitChecker):
        mock_checker = MagicMock()
        mock_checker.get_file_info.return_value = {
            "commit_hash": "abc123",
            "message": "Update drc_001 to v1.2.0"
        }
        
        with patch.object(self.matcher, 'git_checker', mock_checker):
            result, msg = self.matcher.check_version(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule",
                "v1.2.0"
            )
            
            self.assertTrue(result)
            
    @patch('version_matcher.GitChecker')
    def test_check_version_mismatch(self, MockGitChecker):
        mock_checker = MagicMock()
        mock_checker.get_file_info.return_value = {
            "commit_hash": "abc123",
            "message": "Update drc_001 to v1.0.0"
        }
        
        with patch.object(self.matcher, 'git_checker', mock_checker):
            result, msg = self.matcher.check_version(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule",
                "v1.2.0"
            )
            
            self.assertFalse(result)
            self.assertIn("mismatch", msg.lower())
            
    @patch('version_matcher.GitChecker')
    def test_check_version_error(self, MockGitChecker):
        mock_checker = MagicMock()
        mock_checker.get_file_info.return_value = {"error": "Network error"}
        
        with patch.object(self.matcher, 'git_checker', mock_checker):
            result, msg = self.matcher.check_version(
                "https://github.com/test/repo.git",
                "rules/drc_001.rule",
                "v1.2.0"
            )
            
            self.assertFalse(result)


if __name__ == "__main__":
    unittest.main()
