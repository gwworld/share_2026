import unittest
import os
import sys
import json
import tempfile
import shutil
from unittest.mock import patch, MagicMock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from main import ReleaseQCOrchestrator


class TestReleaseQCOrchestrator(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.test_data_dir = os.path.join(self.test_dir, "test_data")
        self.temp_output_dir = tempfile.mkdtemp()
        
    def tearDown(self):
        if os.path.exists(self.temp_output_dir):
            shutil.rmtree(self.temp_output_dir)
            
    def test_orchestrator_initialization(self):
        config_path = os.path.join(self.test_dir, "test_config.json")
        
        if os.path.exists(config_path):
            orchestrator = ReleaseQCOrchestrator(config_path)
            
            self.assertIsNotNone(orchestrator.config)
            self.assertIsNotNone(orchestrator.parser)
            self.assertIsNotNone(orchestrator.git_checker)
            
    def test_orchestrator_loads_config(self):
        config_path = os.path.join(self.test_dir, "test_config.json")
        
        if os.path.exists(config_path):
            orchestrator = ReleaseQCOrchestrator(config_path)
            
            self.assertEqual(orchestrator.config["smtp"]["host"], "smtp.test.com")
            self.assertEqual(orchestrator.config["qc"]["block_on_failure"], False)
            
    def test_orchestrator_missing_config(self):
        with self.assertRaises(FileNotFoundError):
            ReleaseQCOrchestrator("nonexistent_config.json")


class TestMainExecution(unittest.TestCase):
    def setUp(self):
        self.test_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        
    def test_main_with_valid_manifest(self):
        manifest_path = os.path.join(self.test_dir, "test_data", "test_release_manifest.json")
        config_path = os.path.join(self.test_dir, "test_config.json")
        
        if os.path.exists(manifest_path) and os.path.exists(config_path):
            orchestrator = ReleaseQCOrchestrator(config_path)
            
            with patch.object(orchestrator.notifier, 'send_report') as mock_send:
                mock_send.return_value = None
                
                report = orchestrator.run_qc(manifest_path, "TEST_INTEGRATION_001")
                
                self.assertIn("release_id", report)
                self.assertIn("results", report)


class TestQCWorkflow(unittest.TestCase):
    def test_qc_result_summary(self):
        qc_results = [
            {
                "file_id": "DRC_001",
                "version": "v1.2.0",
                "checks": {
                    "file_exists": {"status": "PASS"},
                    "version_match": {"status": "PASS"},
                    "pushed_to_remote": {"status": "PASS"},
                    "is_latest": {"status": "PASS"}
                },
                "overall_status": "PASS"
            },
            {
                "file_id": "DRC_002",
                "version": "v2.0.0",
                "checks": {
                    "file_exists": {"status": "PASS"},
                    "version_match": {"status": "FAIL"},
                    "pushed_to_remote": {"status": "PASS"},
                    "is_latest": {"status": "PASS"}
                },
                "overall_status": "FAIL"
            }
        ]
        
        passed = sum(1 for r in qc_results if r["overall_status"] == "PASS")
        failed = sum(1 for r in qc_results if r["overall_status"] == "FAIL")
        
        self.assertEqual(passed, 1)
        self.assertEqual(failed, 1)


if __name__ == "__main__":
    unittest.main()
