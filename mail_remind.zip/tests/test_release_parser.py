import unittest
import os
import sys
import json
import tempfile
import csv

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from release_parser import ReleaseParser


class TestReleaseParser(unittest.TestCase):
    def setUp(self):
        self.parser = ReleaseParser()
        self.test_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "test_data")
        
    def test_parse_json_valid(self):
        test_file = os.path.join(self.test_dir, "test_release_manifest.json")
        
        result = self.parser.parse(test_file)
        
        self.assertIn("items", result)
        self.assertEqual(len(result["items"]), 3)
        self.assertEqual(result["items"][0]["file_id"], "DRC_001")
        
    def test_parse_json_file_not_found(self):
        with self.assertRaises(FileNotFoundError):
            self.parser.parse("nonexistent.json")
            
    def test_parse_csv_valid(self):
        csv_file = os.path.join(self.test_dir, "test_release_manifest.csv")
        
        result = self.parser.parse(csv_file)
        
        self.assertIn("items", result)
        self.assertEqual(len(result["items"]), 2)
        
    def test_parse_unsupported_format(self):
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False, mode='w') as f:
            f.write("test content")
            temp_path = f.name
            
        try:
            with self.assertRaises(ValueError):
                self.parser.parse(temp_path)
        finally:
            os.unlink(temp_path)
            
    def test_validate_manifest_valid(self):
        manifest = {
            "items": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.0",
                    "git_repo": "https://github.com/test/repo.git",
                    "file_path": "rules/test.rule"
                }
            ]
        }
        
        errors = self.parser.validate_manifest(manifest)
        
        self.assertEqual(len(errors), 0)
        
    def test_validate_manifest_missing_items(self):
        manifest = {}
        
        errors = self.parser.validate_manifest(manifest)
        
        self.assertIn("Missing 'items' key in manifest", errors[0])
        
    def test_validate_manifest_missing_fields(self):
        manifest = {
            "items": [
                {
                    "file_id": "DRC_001",
                    "version": "v1.0"
                }
            ]
        }
        
        errors = self.parser.validate_manifest(manifest)
        
        self.assertGreater(len(errors), 0)


class TestReleaseParserCSV(unittest.TestCase):
    def setUp(self):
        self.parser = ReleaseParser()
        self.test_dir = os.path.dirname(os.path.abspath(__file__))
        
    def test_parse_csv_direct(self):
        csv_content = """file_id,version,git_repo,file_path
DRC_001,v1.0,https://github.com/test/repo.git,rules/drc_001.rule
DRC_002,v2.0,https://github.com/test/repo.git,rules/drc_002.rule"""
        
        with tempfile.NamedTemporaryFile(suffix=".csv", delete=False, mode='w') as f:
            f.write(csv_content)
            csv_path = f.name
            
        try:
            result = self.parser.parse(csv_path)
            
            self.assertIn("items", result)
            self.assertEqual(len(result["items"]), 2)
            self.assertEqual(result["items"][0]["file_id"], "DRC_001")
            self.assertEqual(result["items"][1]["file_id"], "DRC_002")
        finally:
            os.unlink(csv_path)


if __name__ == "__main__":
    unittest.main()
