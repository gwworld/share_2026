import json
import csv
import os
from typing import Dict, List, Any


class ReleaseParser:
    SUPPORTED_FORMATS = ['json', 'csv']
    
    def __init__(self):
        self.manifest_data = {}
    
    def parse(self, manifest_path: str) -> Dict[str, Any]:
        if not os.path.exists(manifest_path):
            raise FileNotFoundError(f"Manifest file not found: {manifest_path}")
        
        ext = os.path.splitext(manifest_path)[1].lower()
        
        if ext == '.json':
            return self._parse_json(manifest_path)
        elif ext == '.csv':
            return self._parse_csv(manifest_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}. Supported: {self.SUPPORTED_FORMATS}")
    
    def _parse_json(self, manifest_path: str) -> Dict[str, Any]:
        with open(manifest_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            return {"items": data}
        return data
    
    def _parse_csv(self, manifest_path: str) -> Dict[str, Any]:
        items = []
        
        with open(manifest_path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                items.append({
                    "file_id": row.get("file_id", ""),
                    "version": row.get("version", ""),
                    "git_repo": row.get("git_repo", ""),
                    "file_path": row.get("file_path", "")
                })
        
        return {"items": items}
    
    def validate_manifest(self, manifest_data: Dict[str, Any]) -> List[str]:
        errors = []
        
        if "items" not in manifest_data:
            errors.append("Missing 'items' key in manifest")
            return errors
        
        required_fields = ["file_id", "version", "git_repo", "file_path"]
        
        for idx, item in enumerate(manifest_data.get("items", [])):
            for field in required_fields:
                if not item.get(field):
                    errors.append(f"Item {idx}: Missing required field '{field}'")
        
        return errors
