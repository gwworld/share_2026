#!/usr/bin/env python
import unittest
import os
import sys
import importlib.util

def load_test_module(test_path):
    module_name = os.path.basename(test_path).replace('.py', '')
    spec = importlib.util.spec_from_file_location(module_name, test_path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)
    return module


def discover_tests():
    test_dir = os.path.dirname(os.path.abspath(__file__))
    
    suite = unittest.TestSuite()
    
    test_files = [
        'tests/test_release_parser.py',
        'tests/test_git_checker.py', 
        'tests/test_version_matcher.py',
        'tests/test_report_generator.py',
        'tests/test_email_notifier.py',
        'tests/test_main.py'
    ]
    
    for test_file in test_files:
        test_path = os.path.join(test_dir, test_file)
        if os.path.exists(test_path):
            module = load_test_module(test_path)
            
            for name in dir(module):
                obj = getattr(module, name)
                if isinstance(obj, type) and issubclass(obj, unittest.TestCase) and obj != unittest.TestCase:
                    suite.addTests(unittest.TestLoader().loadTestsFromTestCase(obj))
    
    return suite


def run_tests():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    
    print("=" * 60)
    print("Running Release QC System Tests")
    print("=" * 60)
    print()
    
    suite = discover_tests()
    
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    print()
    print("=" * 60)
    print("Test Summary")
    print("=" * 60)
    print(f"Tests Run: {result.testsRun}")
    print(f"Failures: {len(result.failures)}")
    print(f"Errors: {len(result.errors)}")
    print(f"Skipped: {len(result.skipped)}")
    
    if result.wasSuccessful():
        print("\n✅ All tests passed!")
        return 0
    else:
        print("\n❌ Some tests failed!")
        return 1


if __name__ == "__main__":
    sys.exit(run_tests())
