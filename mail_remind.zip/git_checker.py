import os
import shutil
import subprocess
import tempfile
from typing import Tuple, Dict, Any


class GitChecker:
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        self.timeout = self.config.get("timeout", 30)
        self.retry_times = self.config.get("retry_times", 3)
        self.clone_depth = self.config.get("clone_depth", 1)
        self.use_ls_remote = self.config.get("use_ls_remote", False)
        self.temp_dir = None
    
    def _run_command(self, cmd: list, cwd: str = None, capture: bool = True) -> Tuple[bool, str, str]:
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=capture,
                text=True,
                timeout=self.timeout
            )
            return result.returncode == 0, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            return False, "", "Command timeout"
        except Exception as e:
            return False, "", str(e)
    
    def _clone_repo(self, repo_url: str) -> str:
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
        
        self.temp_dir = tempfile.mkdtemp(prefix="git_qc_")
        
        success, stdout, stderr = self._run_command([
            "git", "clone",
            "--depth", str(self.clone_depth),
            "--bare",
            repo_url,
            self.temp_dir
        ])
        
        if not success:
            raise RuntimeError(f"Failed to clone repo: {stderr}")
        
        return self.temp_dir
    
    def check_file_exists(self, repo_url: str, file_path: str) -> Tuple[bool, str]:
        try:
            repo_dir = self._clone_repo(repo_url)
            
            success, stdout, stderr = self._run_command([
                "git", "-C", repo_dir, "ls-files"
            ])
            
            files = stdout.strip().split('\n') if stdout.strip() else []
            
            if file_path in files:
                return True, f"File exists in repository: {file_path}"
            
            for f in files:
                if f.endswith(file_path.split('/')[-1]):
                    return True, f"File found (similar): {f}"
            
            return False, f"File not found in repository: {file_path}"
            
        except Exception as e:
            return False, f"Error checking file existence: {str(e)}"
    
    def check_file_pushed(self, repo_url: str, file_path: str) -> Tuple[bool, str]:
        try:
            repo_dir = self._clone_repo(repo_url)
            
            success, stdout, stderr = self._run_command([
                "git", "-C", repo_dir, "log", "-1", "--pretty=%H"
            ])
            
            if success and stdout.strip():
                commit_hash = stdout.strip()[:8]
                return True, f"File has been pushed to remote. Latest commit: {commit_hash}"
            
            return False, "Unable to verify remote push status"
            
        except Exception as e:
            return False, f"Error checking remote push status: {str(e)}"
    
    def check_file_latest(self, repo_url: str, file_path: str, expected_version: str) -> Tuple[bool, str]:
        try:
            repo_dir = self._clone_repo(repo_url)
            
            success, stdout, stderr = self._run_command([
                "git", "-C", repo_dir, "log", "-1", "--pretty=%B", "--", file_path
            ])
            
            if success:
                commit_msg = stdout.strip()
                if expected_version in commit_msg or expected_version.replace('v', '') in commit_msg:
                    return True, f"File version matches expected: {expected_version}"
                
                return True, f"File exists (version check via commit message)"
            
            return False, "Unable to verify file version"
            
        except Exception as e:
            return False, f"Error checking file version: {str(e)}"
    
    def get_file_info(self, repo_url: str, file_path: str) -> Dict[str, Any]:
        try:
            repo_dir = self._clone_repo(repo_url)
            
            info = {}
            
            success, stdout, _ = self._run_command([
                "git", "-C", repo_dir, "log", "-1", "--pretty=%H|%an|%ae|%ad|%B", "--", file_path
            ])
            
            if success and stdout.strip():
                parts = stdout.strip().split('|')
                if len(parts) >= 5:
                    info["commit_hash"] = parts[0][:8]
                    info["author"] = parts[1]
                    info["email"] = parts[2]
                    info["date"] = parts[3]
                    info["message"] = '|'.join(parts[4:])
            
            return info
            
        except Exception as e:
            return {"error": str(e)}
    
    def cleanup(self):
        if self.temp_dir and os.path.exists(self.temp_dir):
            shutil.rmtree(self.temp_dir)
            self.temp_dir = None
