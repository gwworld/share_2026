import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Any

from release_parser import ReleaseParser
from git_checker import GitChecker
from version_matcher import VersionMatcher
from report_generator import ReportGenerator
from email_notifier import EmailNotifier


class ReleaseQCOrchestrator:
    def __init__(self, config_path: str = "config.json"):
        self.config = self._load_config(config_path)
        self.parser = ReleaseParser()
        self.git_checker = GitChecker(self.config.get("git", {}))
        self.version_matcher = VersionMatcher()
        self.report_generator = ReportGenerator(self.config.get("qc", {}))
        self.notifier = EmailNotifier(self.config.get("smtp", {}), self.config.get("email", {}))

    def _load_config(self, config_path: str) -> Dict[str, Any]:
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def run_qc(self, manifest_file: str, release_id: str = None) -> Dict[str, Any]:
        release_id = release_id or datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print(f"[QC] Starting Release QC for: {release_id}")
        
        manifest_data = self.parser.parse(manifest_file)
        print(f"[QC] Loaded {len(manifest_data.get('items', []))} items from manifest")
        
        qc_results = []
        
        for item in manifest_data.get("items", []):
            file_id = item.get("file_id")
            version = item.get("version")
            git_repo = item.get("git_repo")
            file_path = item.get("file_path")
            
            result = {
                "file_id": file_id,
                "version": version,
                "git_repo": git_repo,
                "file_path": file_path,
                "checks": {}
            }
            
            file_exists, file_msg = self.git_checker.check_file_exists(git_repo, file_path)
            result["checks"]["file_exists"] = {
                "status": "PASS" if file_exists else "FAIL",
                "message": file_msg
            }
            
            version_match, version_msg = self.version_matcher.check_version(
                git_repo, file_path, version
            )
            result["checks"]["version_match"] = {
                "status": "PASS" if version_match else "FAIL",
                "message": version_msg
            }
            
            pushed, pushed_msg = self.git_checker.check_file_pushed(git_repo, file_path)
            result["checks"]["pushed_to_remote"] = {
                "status": "PASS" if pushed else "FAIL",
                "message": pushed_msg
            }
            
            latest, latest_msg = self.git_checker.check_file_latest(git_repo, file_path, version)
            result["checks"]["is_latest"] = {
                "status": "PASS" if latest else "FAIL",
                "message": latest_msg
            }
            
            overall_status = all(
                check["status"] == "PASS" 
                for check in result["checks"].values()
            )
            result["overall_status"] = "PASS" if overall_status else "FAIL"
            
            qc_results.append(result)
            
            status_symbol = "✓" if overall_status else "✗"
            print(f"[QC] {status_symbol} {file_id} ({version}): {result['overall_status']}")
        
        report = self.report_generator.generate(qc_results, release_id)
        
        failed_count = sum(1 for r in qc_results if r["overall_status"] == "FAIL")
        
        if failed_count > 0:
            print(f"[QC] QC FAILED: {failed_count} items failed validation")
            if self.config.get("qc", {}).get("block_on_failure", True):
                print("[QC] Blocking release due to QC failures")
        else:
            print(f"[QC] QC PASSED: All {len(qc_results)} items validated successfully")
        
        self.notifier.send_report(report, release_id)
        
        return report


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Release QC System")
    parser.add_argument("-m", "--manifest", required=True, help="Path to release manifest file")
    parser.add_argument("-c", "--config", default="config.json", help="Path to configuration file")
    parser.add_argument("-r", "--release-id", help="Release ID (default: timestamp)")
    
    args = parser.parse_args()
    
    if not os.path.exists(args.manifest):
        print(f"Error: Manifest file not found: {args.manifest}")
        sys.exit(1)
    
    try:
        orchestrator = ReleaseQCOrchestrator(args.config)
        report = orchestrator.run_qc(args.manifest, args.release_id)
        
        failed_count = sum(1 for r in report.get("results", []) if r["overall_status"] == "FAIL")
        
        if failed_count > 0:
            sys.exit(1)
        else:
            sys.exit(0)
            
    except Exception as e:
        print(f"Error: {str(e)}")
        sys.exit(2)


if __name__ == "__main__":
    main()
