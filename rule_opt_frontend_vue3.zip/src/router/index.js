import { createRouter, createWebHistory } from 'vue-router'
import RulesView from '../views/RulesView.vue'
import TemplatesView from '../views/TemplatesView.vue'
import LayersView from '../views/LayersView.vue'

const routes = [
  {
    path: '/',
    redirect: '/rules'
  },
  {
    path: '/rules',
    name: 'Rules',
    component: RulesView
  },
  {
    path: '/templates',
    name: 'Templates',
    component: TemplatesView
  },
  {
    path: '/layers',
    name: 'Layers',
    component: LayersView
  }
]

const router = createRouter({
  mode: 'history',
  history: createWebHistory(),
  routes
})

export default router
